import streamlit as st
import pandas as pd

from data_loader import load_sample, get_columns


# ---------- Shared Header ----------
def page_header(title: str, subtitle: str = "", key: str = "back"):
    st.title(title)
    if subtitle:
        st.caption(subtitle)

    if st.button("⬅️ Back to Home", key=key):
        st.session_state.page = "home"
        st.rerun()

    st.divider()


# ---------- Section 1: Data ----------
def render_data_overview():
    page_header(
        "📊 Dataset Overview",
        "Divar real estate ads — schema, size, and missing values",
        key="back_overview",
    )

    try:
        cols = get_columns()
    except FileNotFoundError:
        st.error("❌ `Divar.csv` not found. Place it next to `app.py`.")
        return

    df = load_sample()

    # ---- Basic Info ----
    st.subheader("Basic Information")
    col1, col2, col3 = st.columns(3)
    col1.metric("Columns", len(cols))
    col2.metric("Sample Rows", f"{len(df):,}")
    col3.metric("Memory (sample)", f"{df.memory_usage(deep=True).sum() / 1e6:.1f} MB")

    # ---- Column List ----
    st.subheader("Column Names")
    st.write(cols)

    # ---- Sample Data ----
    st.subheader("Sample Rows")
    st.dataframe(df.head(20), use_container_width=True)

    # ---- Missing Values ----
    st.subheader("Missing Values (sample)")
    missing = df.isna().sum().reset_index()
    missing.columns = ["Column", "Missing"]
    missing["Percent"] = (missing["Missing"] / len(df) * 100).round(2)
    missing = missing.sort_values("Missing", ascending=False)

    st.dataframe(missing, use_container_width=True)

    # ---- Data Types ----
    st.subheader("Data Types")
    dtypes = df.dtypes.astype(str).reset_index()
    dtypes.columns = ["Column", "Dtype"]
    st.dataframe(dtypes, use_container_width=True)


# ---------- Section 2: Statistics ----------
def render_descriptive_stats():
    page_header(
        "📈 Descriptive Statistics",
        "Distributions, trends, and correlations",
        key="back_desc",
    )
    st.info("This page will contain 9 descriptive analysis tabs.")


def render_hypothesis_tests():
    page_header(
        "🔬 Hypothesis Testing",
        "Statistical tests on market assumptions",
        key="back_hyp",
    )
    st.info("This page will contain 4 hypothesis tests.")


# ---------- Section 3: Machine Learning ----------
def render_clustering():
    page_header(
        "🎯 Clustering / Recommender",
        "K-Means and DBSCAN for property recommendation",
        key="back_cluster",
    )
    st.info("This page will contain K-Means, Elbow Method, and DBSCAN.")


def render_price_prediction():
    page_header(
        "💰 Price Prediction",
        "Predict rent or sale price based on property features",
        key="back_price",
    )
    st.info("This page will contain model training and evaluation (R², MAE, MSE).")


# ---------- About ----------
def render_about():
    page_header("ℹ️ About", "Project information", key="back_about")
    st.markdown("""
    **Divar Real Estate Analytics**

    - **Course:** Quera AI Bootcamp — Summer 2026
    - **Project:** Real estate ads analysis and prediction
    - **Stack:** Python, Streamlit, Plotly, scikit-learn, pandas
    """)