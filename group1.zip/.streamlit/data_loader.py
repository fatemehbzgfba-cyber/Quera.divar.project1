import streamlit as st
import pandas as pd


DATA_PATH = "Divar.csv"


@st.cache_data(show_spinner="Loading dataset...")
def load_full_data() -> pd.DataFrame:
    """Loads the full dataset (cached)."""
    df = pd.read_csv(DATA_PATH, low_memory=False)
    return df


@st.cache_data(show_spinner="Loading sample...")
def load_sample(n: int = 100_000) -> pd.DataFrame:
    """Loads a random sample for fast prototyping."""
    df = pd.read_csv(DATA_PATH, nrows=n, low_memory=False)
    return df


@st.cache_data(show_spinner="Reading columns...")
def get_columns() -> list:
    """Reads only the header to get column names quickly."""
    return pd.read_csv(DATA_PATH, nrows=0).columns.tolist()