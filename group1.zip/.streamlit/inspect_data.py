import pandas as pd

DATA_PATH = "Divar.csv"

print("=" * 60)
print("DATASET INSPECTION")
print("=" * 60)

# ---- 1. Columns + dtypes (fast, header only) ----
print("\n[1] COLUMNS AND DTYPES")
print("-" * 60)
header = pd.read_csv(DATA_PATH, nrows=0)
for i, col in enumerate(header.columns, 1):
    print(f"{i:3d}. {col}")

print(f"\nTotal columns: {len(header.columns)}")

# ---- 2. Load a sample ----
print("\n[2] LOADING SAMPLE (50000 rows)...")
print("-" * 60)
df = pd.read_csv(DATA_PATH, nrows=50_000, low_memory=False)
print(f"Sample shape: {df.shape}")

# ---- 3. Dtypes ----
print("\n[3] DATA TYPES")
print("-" * 60)
print(df.dtypes.to_string())

# ---- 4. Missing values ----
print("\n[4] MISSING VALUES (in sample, sorted)")
print("-" * 60)
missing = df.isna().sum()
missing_pct = (missing / len(df) * 100).round(2)
missing_df = pd.DataFrame({
    "missing_count": missing,
    "missing_pct": missing_pct
}).sort_values("missing_count", ascending=False)
print(missing_df.to_string())

# ---- 5. Categorical previews ----
print("\n[5] CATEGORICAL VALUE COUNTS")
print("-" * 60)
categorical_cols = ["cat2_slug", "cat3_slug", "city_slug",
                    "rent_mode", "rent_type", "price_mode",
                    "credit_mode", "user_type", "deed_type",
                    "property_type"]
for col in categorical_cols:
    if col in df.columns:
        print(f"\n>>> {col} (unique: {df[col].nunique()})")
        print(df[col].value_counts().head(10).to_string())

# ---- 6. created_at_month format ----
print("\n[6] created_at_month FORMAT")
print("-" * 60)
if "created_at_month" in df.columns:
    print(f"dtype: {df['created_at_month'].dtype}")
    print(f"unique count: {df['created_at_month'].nunique()}")
    print("First 20 unique values:")
    print(sorted(df["created_at_month"].dropna().unique())[:20])

# ---- 7. Numeric columns summary ----
print("\n[7] NUMERIC COLUMNS SUMMARY")
print("-" * 60)
numeric_cols = ["price_value", "rent_value", "credit_value",
                "land_size", "building_size", "rooms_count",
                "construction_year", "floor",
                "location_latitude", "location_longitude"]
available = [c for c in numeric_cols if c in df.columns]
print(df[available].describe().T.to_string())

# ---- 8. Sample rows ----
print("\n[8] FIRST 3 ROWS")
print("-" * 60)
pd.set_option("display.max_columns", None)
pd.set_option("display.width", 200)
print(df.head(3).T.to_string())

print("\n" + "=" * 60)
print("DONE")
print("=" * 60)