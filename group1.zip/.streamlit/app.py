import os
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go


# ============================================================
# PAGE CONFIGURATION
# ============================================================
st.set_page_config(
    page_title="Divar Real Estate Analytics",
    page_icon="🏠",
    layout="wide",
    initial_sidebar_state="collapsed",
)


# ============================================================
# BASE DIRECTORY (for images)
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# ============================================================
# CUSTOM CSS
# ============================================================
st.markdown("""
<style>
    /* ---------- Global ---------- */
    .main {
        background-color: #f7f9fc;
    }

    /* ============================================================
       SUPERVISOR CARD
       ============================================================ */
    .supervisor-card {
        background: linear-gradient(135deg, #4c1d95 0%, #7c3aed 50%, #a855f7 100%);
        padding: 20px 20px;
        border-radius: 18px;
        color: #ffffff;
        text-align: center;
        box-shadow: 0 8px 24px rgba(124, 58, 237, 0.25);
        margin-bottom: 10px;
        height: 210px;
        min-height: 210px;
        display: grid;
        grid-template-rows: 50px 40px 22px 34px;
        align-content: center;
        justify-items: center;
        gap: 4px;
        overflow: hidden;
        border: 1px solid rgba(255, 255, 255, 0.15);
    }
    .supervisor-card .icon {
        font-size: 40px;
        line-height: 50px;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .supervisor-card .name {
        font-size: 20px;
        font-weight: 700;
        line-height: 1.2;
        height: 40px;
        max-height: 40px;
        width: 100%;
        padding: 0 4px;
        text-align: center;
        display: flex;
        align-items: flex-start;
        justify-content: center;
        overflow: hidden;
        overflow-wrap: break-word;
        word-break: normal;
    }
    .supervisor-card .role {
        font-size: 14px;
        line-height: 22px;
        height: 22px;
        opacity: 0.9;
        text-align: center;
    }
    .supervisor-card .email {
        font-size: 13px;
        line-height: 17px;
        height: 34px;
        max-height: 34px;
        opacity: 0.8;
        text-align: center;
        overflow: hidden;
        word-break: break-all;
        width: 100%;
        padding: 0 4px;
    }

    /* ============================================================
       MEMBER CARD
       ============================================================ */
    .member-card {
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 55%, #3b82f6 100%);
        padding: 18px 10px;
        border-radius: 16px;
        color: #ffffff;
        text-align: center;
        box-shadow: 0 6px 18px rgba(37, 99, 235, 0.22);
        margin-bottom: 10px;
        height: 220px;
        min-height: 220px;
        display: grid;
        grid-template-rows: 40px 36px 22px 34px;
        align-content: center;
        justify-items: center;
        gap: 4px;
        overflow: hidden;
        border: 1px solid rgba(255, 255, 255, 0.12);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .member-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 10px 24px rgba(37, 99, 235, 0.32);
    }
    .member-card .icon {
        font-size: 32px;
        line-height: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .member-card .name {
        font-size: 14px;
        font-weight: 700;
        line-height: 1.25;
        height: 36px;
        max-height: 36px;
        width: 100%;
        padding: 0 4px;
        text-align: center;
        display: flex;
        align-items: flex-start;
        justify-content: center;
        overflow: hidden;
        overflow-wrap: break-word;
        word-break: normal;
    }
    .member-card .role {
        font-size: 12.5px;
        line-height: 22px;
        height: 22px;
        opacity: 0.9;
        text-align: center;
    }
    .member-card .email {
        font-size: 11px;
        line-height: 17px;
        height: 34px;
        max-height: 34px;
        opacity: 0.75;
        text-align: center;
        overflow: hidden;
        word-break: break-all;
        width: 100%;
        padding: 0 4px;
    }

    /* ============================================================
       BUTTONS
       ============================================================ */
    .stButton > button {
        width: 100%;
        height: 60px;
        font-size: 15px;
        border-radius: 12px;
        font-weight: 600;
        border: 1.5px solid #dbeafe;
        background-color: #ffffff;
        color: #1e3a8a;
        transition: all 0.2s ease;
    }
    .stButton > button:hover {
        border-color: #2563eb;
        background-color: #eff6ff;
        color: #1e40af;
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.15);
    }

    /* ============================================================
       SECTION HEADERS
       ============================================================ */
    .section-header {
        background: linear-gradient(90deg, #eff6ff 0%, #f7f9fc 100%);
        padding: 12px 18px;
        border-radius: 10px;
        margin: 28px 0 14px 0;
        border-left: 5px solid #2563eb;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
    }
    .section-header h3 {
        margin: 0;
        font-size: 16px;
        font-weight: 700;
        color: #1e3a8a;
        letter-spacing: 0.2px;
    }

    /* ============================================================
       CLUSTERING PAGE — STAT CARDS & NOTE BOXES
       ============================================================ */
    .stat-card {
        background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        border-left: 4px solid #2563eb;
        padding: 16px 18px;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(37, 99, 235, 0.08);
    }
    .stat-card .value {
        font-size: 24px;
        font-weight: 800;
        color: #1e3a8a;
        line-height: 1.1;
    }
    .stat-card .label {
        font-size: 13px;
        color: #475569;
        margin-top: 6px;
    }
    .stat-card .sub {
        font-size: 11px;
        color: #64748b;
        margin-top: 2px;
    }
    .stat-card.warn {
        background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
        border-left-color: #d97706;
    }
    .stat-card.warn .value { color: #92400e; }
    .stat-card.warn .label { color: #78350f; }

    .note-box {
        background: #eff6ff;
        border-left: 4px solid #3b82f6;
        padding: 14px 18px;
        border-radius: 10px;
        color: #1e3a8a;
        font-size: 14.5px;
        line-height: 1.9;
        margin: 14px 0;
        direction: rtl;
        text-align: right;
    }
    .note-box.warn {
        background: #fef3c7;
        border-left-color: #d97706;
        color: #78350f;
    }
    .note-box.info {
        background: #ecfeff;
        border-left-color: #0891b2;
        color: #155e75;
    }

    .rtl-text {
        direction: rtl;
        text-align: right;
        font-size: 14.5px;
        line-height: 1.9;
        color: #334155;
        margin: 10px 0;
    }

    .subtab-title {
        font-size: 20px;
        font-weight: 700;
        color: #1e3a8a;
        margin: 6px 0 12px 0;
        direction: rtl;
        text-align: right;
    }

    /* ---------- Subheaders ---------- */
    h2 {
        color: #1e3a8a !important;
        font-weight: 700 !important;
    }
</style>
""", unsafe_allow_html=True)


# ============================================================
# SESSION STATE
# ============================================================
if "page" not in st.session_state:
    st.session_state.page = "home"


def go_to(page_name: str):
    st.session_state.page = page_name
    st.rerun()


# ============================================================
# SUPERVISOR
# ============================================================
SUPERVISOR = {
    "name": "Melika Molaei",
    "role": "Project Supervisor",
    "email": "melika.molaei@example.com",
}


# ============================================================
# GROUP MEMBERS
# ============================================================
MEMBERS = [
    {"name": "Haniyeh Rashidian",   "role": "Student", "email": "rashidianhaniyeh@gmail.com"},
    {"name": "Sina Bahramian",      "role": "Student", "email": "mohamad.sina1383@gmail.com"},
    {"name": "Fateme Bazgir",       "role": "Student", "email": "Fatemehbzg.fba@gmail.com"},
    {"name": "Fateme Shakibamehr",  "role": "Student", "email": "Fatemeshakiba1045@gmail.com"},
    {"name": "Pourya Einolghazaei", "role": "Student", "email": "pourya.civil@gmail.com"},
]


# ============================================================
# SHARED HEADER
# ============================================================
def page_header(title: str, subtitle: str = "", key: str = "back"):
    st.title(title)
    if subtitle:
        st.caption(subtitle)

    if st.button("⬅️ Back to Home", key=key):
        go_to("home")

    st.divider()


# ============================================================
# HOME PAGE
# ============================================================
def home_page():
    st.title("🏠 Divar Real Estate Analytics")
    st.caption("Quera AI Bootcamp — Summer 2026 — Project 1")
    st.divider()

    # ============================================================
    # SUPERVISOR SECTION
    # ============================================================
    st.subheader("🎓 Project Supervisor")
    sup_col1, sup_col2, sup_col3 = st.columns([1, 2, 1])
    with sup_col2:
        st.markdown(f"""
        <div class="supervisor-card">
            <div class="icon">👩‍🏫</div>
            <div class="name">{SUPERVISOR['name']}</div>
            <div class="role">{SUPERVISOR['role']}</div>
            <div class="email">📧 {SUPERVISOR['email']}</div>
        </div>
        """, unsafe_allow_html=True)

    st.divider()

    # ============================================================
    # TEAM SECTION
    # ============================================================
    st.subheader("👥 Project Team")
    cols = st.columns(len(MEMBERS), gap="small")
    for i, m in enumerate(MEMBERS):
        with cols[i]:
            st.markdown(f"""
            <div class="member-card">
                <div class="icon">👤</div>
                <div class="name">{m['name']}</div>
                <div class="role">{m['role']}</div>
                <div class="email">📧 {m['email']}</div>
            </div>
            """, unsafe_allow_html=True)

    # ---- Section 1 ----
    st.markdown(
        '<div class="section-header"><h3>📁 Section 1 — Data</h3></div>',
        unsafe_allow_html=True,
    )
    if st.button("📈 EDA", use_container_width=True):
        go_to("eda")

    # ---- Section 2 ----
    st.markdown(
        '<div class="section-header"><h3>🧪 Section 2 — Statistical Analysis</h3></div>',
        unsafe_allow_html=True,
    )
    c1, c2 = st.columns(2)
    with c1:
        if st.button("📊 Descriptive Statistics", use_container_width=True):
            go_to("descriptive_stats")
    with c2:
        if st.button("🔬 Hypothesis Testing", use_container_width=True):
            go_to("hypothesis_tests")

    # ---- Section 3 ----
    st.markdown(
        '<div class="section-header"><h3>🤖 Section 3 — Machine Learning</h3></div>',
        unsafe_allow_html=True,
    )
    c3, c4 = st.columns(2)
    with c3:
        if st.button("🎯 Clustering / Recommender", use_container_width=True):
            go_to("clustering")
    with c4:
        if st.button("💰 Regression", use_container_width=True):
            go_to("regression")

    st.divider()
    if st.button("ℹ️ About", use_container_width=True):
        go_to("about")


# ============================================================
# SECTION 1 — EDA (placeholder)
# ============================================================
def eda_page():
    page_header(
        "📈 EDA",
        "Exploratory Data Analysis",
        key="back_eda",
    )
    st.info("This page will contain exploratory data analysis.")
    st.write("Coming soon...")


# ============================================================
# SECTION 2 — STATISTICS
# ============================================================
def descriptive_stats_page():
    page_header(
        "📊 Descriptive Statistics",
        "Distributions, trends, and correlations",
        key="back_desc",
    )
    st.info("This page will contain 9 descriptive analysis tabs.")
    st.write("Coming soon...")


def hypothesis_tests_page():
    page_header(
        "🔬 Hypothesis Testing",
        "Statistical tests on market assumptions",
        key="back_hyp",
    )
    st.info("This page will contain 4 hypothesis tests.")
    st.write("Coming soon...")


# ============================================================
# CLUSTERING — HELPERS
# ============================================================
def stat_cards(items, cols_per_row=None):
    if cols_per_row is None:
        cols_per_row = len(items)
    cols = st.columns(cols_per_row)
    for i, item in enumerate(items):
        with cols[i % cols_per_row]:
            warn_cls = " warn" if item.get("warn") else ""
            sub_html = f'<div class="sub">{item["sub"]}</div>' if item.get("sub") else ""
            st.markdown(f"""
            <div class="stat-card{warn_cls}">
                <div class="value">{item['value']}</div>
                <div class="label">{item['label']}</div>
                {sub_html}
            </div>
            """, unsafe_allow_html=True)


def note_box(text, kind=""):
    kind_cls = f" {kind}" if kind else ""
    st.markdown(f'<div class="note-box{kind_cls}">{text}</div>', unsafe_allow_html=True)


def show_image(filename, caption="", width=750):
    path = os.path.join(BASE_DIR, filename)
    if not os.path.exists(path):
        st.warning(f"⚠️ Image not found: `{filename}`")
        return
    col_left, col_center, col_right = st.columns([1, 5, 1])
    with col_center:
        st.image(path, caption=caption, width=width)


# ============================================================
# CLUSTERING PAGE
# ============================================================
def clustering_page():
    page_header(
        "🎯 Clustering / Recommender",
        "K-Means, k-selection, and DBSCAN on Divar real estate data",
        key="back_cluster",
    )

    tabs = st.tabs([
        "📌 Overview",
        "🧹 Data Prep",
        "🎯 Feature Selection",
        "🔵 Part 1 — K-Means k=10",
        "📐 Part 2 — Choosing k",
        "🔶 Part 3 — DBSCAN",
        "📋 Limitations",
    ])

    # ========================================================
    # TAB 1 — OVERVIEW
    # ========================================================
    with tabs[0]:
        st.markdown('<div class="subtab-title">مرور کلی پروژه</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "1,000,000", "label": "Total Ads",             "sub": "Divar dataset"},
            {"value": "3",         "label": "Independent Groups",     "sub": "sale / rent / daily"},
            {"value": "4",         "label": "Selected Features",      "sub": "for clustering"},
            {"value": "3",         "label": "Exercise Sub-questions", "sub": "Part 1, 2, 3"},
        ])

        st.markdown("##### N1 — Dataset Split")
        pie_df = pd.DataFrame({
            "Group": ["Sale", "Rent", "Daily Rent", "Real Estate Services"],
            "Count": [597569, 353125, 29903, 19403],
        })
        fig = px.pie(
            pie_df, names="Group", values="Count",
            color_discrete_sequence=["#1e3a8a", "#2563eb", "#60a5fa", "#cbd5e1"],
            hole=0.35,
        )
        fig.update_traces(textposition="outside", textinfo="percent+label")
        fig.update_layout(font=dict(size=13), margin=dict(l=20, r=20, t=20, b=20), height=440)
        st.plotly_chart(fig, use_container_width=True)

        note_box(
            "سه گروه اول به‌صورت مستقل خوشه‌بندی می‌شوند چون واحد اقتصادی‌شان متفاوت است: "
            "میلیارد تومان برای فروش، میلیون ماهانه برای رهن، صد هزار شبانه برای روزانه. "
            "خدمات ملکی کنار گذاشته شد چون آگهی مشاور و پیمانکار اصلاً ملک نیست."
        )

        st.markdown("##### Project Architecture")
        arch_df = pd.DataFrame([
            {"Path": "A — Preparation",   "Description": "Prerequisite for all paths"},
            {"Path": "B — Main Question", "Description": "Official answer (Parts 1, 2, 3)"},
            {"Path": "C — Supplementary", "Description": "K-Means in extended feature space"},
            {"Path": "D — Alternative",   "Description": "DBSCAN with shared UTM and ECEF"},
        ])
        st.dataframe(arch_df, use_container_width=True, hide_index=True)

    # ========================================================
    # TAB 2 — DATA PREPARATION
    # ========================================================
    with tabs[1]:
        st.markdown('<div class="subtab-title">آماده‌سازی داده</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "724",   "label": "Recovered \"30+\" values"},
            {"value": "1,252", "label": "Floor mismatches", "sub": "740 sale + 512 rent"},
            {"value": "676",   "label": "Zero daily rates",  "sub": "across 328 ads"},
            {"value": "1",     "label": "Only numeric fix",  "sub": "zero → missing"},
        ])

        st.markdown("##### Cell-Level Fixes (Cell 30)")
        fix_df = pd.DataFrame([
            {"Column": "rent_price_on_regular_days", "Cells Changed": 207, "Missing Before": 11835, "Missing After": 12042},
            {"Column": "rent_price_on_special_days", "Cells Changed": 241, "Missing Before": 19440, "Missing After": 19681},
            {"Column": "rent_price_at_weekends",     "Cells Changed": 228, "Missing Before": 16352, "Missing After": 16580},
        ])
        st.dataframe(fix_df, use_container_width=True, hide_index=True)

        st.markdown("##### Filtering Pipeline")
        pipe_df = pd.DataFrame([
            {"Group": "Sale",  "Raw": 597569, "Feature Eligible": 545200, "Spatial Eligible": 362647},
            {"Group": "Rent",  "Raw": 353125, "Feature Eligible": 338688, "Spatial Eligible": 230439},
            {"Group": "Daily", "Raw": 29903,  "Feature Eligible": 17180,  "Spatial Eligible": 12046},
        ])
        st.dataframe(pipe_df, use_container_width=True, hide_index=True)

        fig = go.Figure()
        for col, color in [("Raw", "#cbd5e1"), ("Feature Eligible", "#60a5fa"), ("Spatial Eligible", "#1e3a8a")]:
            fig.add_trace(go.Bar(
                name=col, x=pipe_df["Group"], y=pipe_df[col],
                marker_color=color,
                text=[f"{v:,}" for v in pipe_df[col]],
                textposition="outside",
            ))
        fig.update_layout(
            barmode="group",
            title="Raw → Feature-Ready → Spatial-Ready",
            yaxis_title="Number of Ads",
            font=dict(size=12),
            title_font=dict(size=16, color="#1e3a8a"),
            margin=dict(l=20, r=20, t=60, b=20),
            height=440,
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        )
        st.plotly_chart(fig, use_container_width=True)

        st.markdown("##### Model Exclusion Reasons")
        excl_df = pd.DataFrame([
            {"Reason": "Price missing",           "Sale": "—",      "Rent": "—",     "Daily": "—"},
            {"Reason": "Non-positive area",       "Sale": "—",      "Rent": "—",     "Daily": "—"},
            {"Reason": "Missing coordinates",     "Sale": "—",      "Rent": "—",     "Daily": "—"},
            {"Reason": "Out of percentile range", "Sale": "11,619", "Rent": "7,203", "Daily": "358"},
        ])
        st.dataframe(excl_df, use_container_width=True, hide_index=True)

        note_box(
            "پاک‌سازی در دو لایه انجام شد. لایهٔ ساختاری: ارقام فارسی به لاتین، بولی‌ها به nullable، "
            "و مقادیر «۳۰+» به حد پایین با فلگ جداگانه. لایهٔ اعتبارسنجی: بیست چک، هیچ‌کدام خودکار اصلاح نکرد. "
            "تنها یک اصلاح عددی: صفر روزانه به missing، چون نرخ صفر یعنی رایگان که در آگهی اجاره بی‌معناست."
        )

        note_box(
            "تنها یک اصلاح عددی در کل پروژه اعمال شد. ۷۴۰ اختلاف طبقه و ۱۷ سال ساخت آینده "
            "فقط فلگ گرفتند، بدون تغییر مقدار. این تصمیم برای حفظ قابلیت حسابرسی است.",
            kind="warn",
        )

    # ========================================================
    # TAB 3 — FEATURE SELECTION
    # ========================================================
    with tabs[2]:
        st.markdown('<div class="subtab-title">انتخاب ویژگی</div>', unsafe_allow_html=True)

        st.markdown("##### Five Selection Criteria")
        crit_df = pd.DataFrame([
            {"Criterion": "User preference relevance",      "Description": "Matches what users choose by"},
            {"Criterion": "Discriminative",                 "Description": "Has diverse values across rows"},
            {"Criterion": "Low correlation",                "Description": "Doesn't add redundant info"},
            {"Criterion": "Avoids curse of dimensionality", "Description": "Keeps feature count under 10"},
            {"Criterion": "Numerical stability",            "Description": "Reasonable scale for distance metrics"},
        ])
        st.dataframe(crit_df, use_container_width=True, hide_index=True)

        st.markdown("##### Feature Decision Table")
        feat_df = pd.DataFrame([
            {"Feature": "Price (per group)",            "Decision": "✅", "Reason": "Main user criterion"},
            {"Feature": "building_size",                "Decision": "✅", "Reason": "Size criterion"},
            {"Feature": "cat3_slug (One-Hot)",          "Decision": "✅", "Reason": "Apartment / Villa / Shop"},
            {"Feature": "UTM_X, UTM_Y",                 "Decision": "✅", "Reason": "Geographic location"},
            {"Feature": "rooms_count",                  "Decision": "❌", "Reason": "Weak correlation with area"},
            {"Feature": "floor",                        "Decision": "❌", "Reason": "Meaningful only for apartments"},
            {"Feature": "construction_year",            "Decision": "❌", "Reason": "High NaN + recording errors"},
            {"Feature": "Boolean flags (parking etc.)", "Decision": "❌", "Reason": "Low variance"},
        ])
        st.dataframe(feat_df, use_container_width=True, hide_index=True)

        st.markdown("##### N2 — Correlation Heatmap")
        show_image("correlation_heatmap.png", "7×7 correlation matrix on 10k sale sample", width=750)

        note_box(
            "ماتریس همبستگی هیچ جفت ویژگی با |r| بالای ۰.۵ نشان نمی‌دهد. "
            "بیشترین مقدار: latitude ↔ longitude = -0.24. "
            "نکتهٔ مهم: حذف rooms_count و floor به‌خاطر همبستگی نبود، "
            "برای سادگی و اجتناب از نفرین ابعاد بود."
        )

    # ========================================================
    # TAB 4 — PART 1
    # ========================================================
    with tabs[3]:
        st.markdown('<div class="subtab-title">Part 1 — K-Means با k=10</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "200,921", "label": "Sale — WCSS",  "sub": "362,647 rows"},
            {"value": "124,420", "label": "Rent — WCSS",  "sub": "230,439 rows"},
            {"value": "4,279",   "label": "Daily — WCSS", "sub": "12,046 rows"},
        ])

        note_box(
            "<b>ماتریس ورودی فقط سه ستون دارد: utm_x, utm_y, log_price.</b> "
            "هیچ ویژگی دیگری — نه مساحت، نه نوع ملک، نه امکانات — وارد نشد. "
            "این رعایت دقیق صورت تمرین است.",
            kind="info",
        )

        st.markdown("##### N3 — K-Means Scatter: Sale")
        show_image("kmeans_scatter_sales.png", "Left: UTM_x vs UTM_y  |  Right: UTM_x vs log(price)", width=1100)

        st.markdown("##### N4 — K-Means Scatter: Rent")
        show_image("kmeans_scatter_rent.png", "Left: UTM_x vs UTM_y  |  Right: UTM_x vs log(price)", width=1100)

        st.markdown("##### N5 — K-Means Scatter: Daily")
        show_image("kmeans_scatter_daily.png", "Note: C7 outlier visible in top-left corner", width=1100)

        st.markdown("##### Three-Step Transformation")
        step_df = pd.DataFrame([
            {"Step": 1, "Action": "Convert coordinates to UTM Zone 39N", "Reason": "Central Iran lies in this zone"},
            {"Step": 2, "Action": "Log-transform price with log1p",      "Reason": "Compress wide numerical range"},
            {"Step": 3, "Action": "StandardScaler on all three columns", "Reason": "Prevent UTM from dominating log_price"},
        ])
        st.dataframe(step_df, use_container_width=True, hide_index=True)

        note_box(
            "در پنل راست، خوشه‌ها به‌صورت نوارهای افقی در سطوح قیمتی مختلف دیده می‌شوند. "
            "یعنی قیمت واقعاً در خوشه‌بندی نقش داشته، نه فقط موقعیت جغرافیایی. "
            "اگر قیمت بی‌اثر بود، همهٔ خوشه‌ها روی یک نوار افقی می‌افتادند. "
            "در پنل چپ، خوشه‌ها به‌صورت بلوک‌های جغرافیایی مجزا دیده می‌شوند."
        )

    # ========================================================
    # TAB 5 — PART 2
    # ========================================================
    with tabs[4]:
        st.markdown('<div class="subtab-title">Part 2 — انتخاب مقدار k</div>', unsafe_allow_html=True)

        st.markdown("##### Best k per Metric")
        k_df = pd.DataFrame([
            {"Metric": "Elbow (WCSS)",      "Sale": 4, "Rent": 4, "Daily": 4},
            {"Metric": "Silhouette",        "Sale": 4, "Rent": 3, "Daily": 4},
            {"Metric": "Davies-Bouldin",    "Sale": 4, "Rent": 4, "Daily": 4},
            {"Metric": "Calinski-Harabasz", "Sale": 7, "Rent": 4, "Daily": 9},
        ])
        st.dataframe(k_df, use_container_width=True, hide_index=True)

        st.markdown("##### N6 — Four Metrics vs k")
        show_image("four_metrics.png", "WCSS · Silhouette · Calinski-Harabasz · Davies-Bouldin", width=1100)

        note_box(
            "Silhouette اوج خود را در k=4 دارد (sales=0.49، rent=0.38، daily=0.55). "
            "Davies-Bouldin کمینهٔ دقیق خود را در k=4. WCSS شیبش در k=4 تغییر می‌کند. "
            "این توافق سه از چهار معیار، شاهد قوی است که ساختار درشت داده چهار قطعه است: "
            "ارزان، متوسط، گران، لاکچری."
        )

        st.markdown("##### k=4 vs k=10")
        cmp_df = pd.DataFrame([
            {"k=4": "Natural data structure", "k=10": "Finer decomposition"},
            {"k=4": "Confirmed by 3 metrics", "k=10": "Required by exercise"},
            {"k=4": "Coarse market segments", "k=10": "Fine-grained taste groups"},
        ])
        st.dataframe(cmp_df, use_container_width=True, hide_index=True)

        note_box(
            "این تناقض نیست. k=4 نشان می‌دهد داده ذاتاً چهار گروه دارد. "
            "k=10 همان گروه‌ها را ریزتر می‌کند. برای سیستم توصیه‌گر، گروه‌های ریزتر "
            "توصیهٔ دقیق‌تر می‌سازند. ما هر دو را گزارش می‌کنیم."
        )

    # ========================================================
    # TAB 6 — PART 3
    # ========================================================
    with tabs[5]:
        st.markdown('<div class="subtab-title">Part 3 — DBSCAN با ۳ خوشه</div>', unsafe_allow_html=True)

        st.markdown("##### Final Hyperparameters")
        db_df = pd.DataFrame([
            {"Group": "Sale",  "eps": 0.45, "min_samples": 250, "Noise": "10.0%", "Distribution": "79.2% + 6.7% + 4.1%"},
            {"Group": "Rent",  "eps": 0.50, "min_samples": 300, "Noise": "8.7%",  "Distribution": "81.8% + 8.4% + 1.1%"},
            {"Group": "Daily", "eps": 0.60, "min_samples": 300, "Noise": "13.8%", "Distribution": "74.0% + 8.7% + 3.4%"},
        ])
        st.dataframe(db_df, use_container_width=True, hide_index=True)

        note_box(
            "پارامترها از یک جستجوی شبکه‌ای دقیق آمد. سه شرط: دقیقاً ۳ خوشه، نویز زیر ۳۰٪، "
            "کوچک‌ترین خوشه حداقل ۵٪. اگر فقط ۳ خوشه شرط بود، با نویز ۹۸٪ هم قابل دسترسی بود که بی‌معناست."
        )

        st.markdown("##### N7 — DBSCAN Scatter: Sale")
        show_image("dbscan_sales.png", "Three clusters + grey noise", width=1100)

        st.markdown("##### N8 — DBSCAN Scatter: Rent")
        show_image("dbscan_rent.png", "Three clusters + grey noise", width=1100)

        st.markdown("##### N9 — DBSCAN Scatter: Daily")
        show_image("dbscan_daily.png", "Three clusters + grey noise", width=1100)

        note_box(
            "خوشه‌ها در فضای مکانی، بلوک‌های کاملاً مجزا هستند. در فضای قیمتی، همپوشانی بیشتری دارند "
            "ولی همچنان قابل تفکیک. این نشان می‌دهد جدایی مکانی قوی‌تر از جدایی قیمتی است."
        )

        st.markdown("##### Cluster Interpretation")
        interp_df = pd.DataFrame([
            {"Cluster": "C0", "Share": "~80%",  "Region": "Central Iran", "Cities": "Tehran, Karaj, Isfahan"},
            {"Cluster": "C1", "Share": "~7-8%", "Region": "East",         "Cities": "Mashhad"},
            {"Cluster": "C2", "Share": "~1-4%", "Region": "South",        "Cities": "Shiraz, Kerman"},
        ])
        st.dataframe(interp_df, use_container_width=True, hide_index=True)

        note_box(
            "این سه منطقه دقیقاً سه قطب اقتصادی بازار مسکن ایران هستند. چرا خوشه‌ها جغرافیایی شدند نه قیمتی؟ "
            "داده‌های مکانی گسسته‌اند — بین شهرها فاصلهٔ خالی بزرگ. داده‌های قیمتی پیوسته‌اند. "
            "DBSCAN که بر اساس چگالی کار می‌کند، گسستگی مکانی را اول می‌بیند. این یافته است، ضعف نیست."
        )

        st.markdown("##### Cluster Profiles")
        prof_df = pd.DataFrame([
            {"Cluster": "C0",    "Count": 31686, "Share": "79.2%", "Median Price": "3 B",   "Top Cities": "Tehran, Karaj", "Type": "apartment"},
            {"Cluster": "C1",    "Count": 2697,  "Share": "6.7%",  "Median Price": "2.6 B", "Top Cities": "Mashhad",       "Type": "apartment"},
            {"Cluster": "C2",    "Count": 1628,  "Share": "4.1%",  "Median Price": "3.55 B","Top Cities": "Shiraz",        "Type": "apartment"},
            {"Cluster": "Noise", "Count": 3989,  "Share": "10.0%", "Median Price": "—",     "Top Cities": "—",             "Type": "—"},
        ])
        st.dataframe(prof_df, use_container_width=True, hide_index=True)

        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown("##### Effect of eps")
            eps_df = pd.DataFrame([
                {"eps": "Small (0.3-0.4)",   "Effect": "Small scattered clusters, high noise"},
                {"eps": "Medium (0.45-0.6)", "Effect": "Meaningful, balanced clusters"},
                {"eps": "Large (1.0+)",      "Effect": "Clusters merge, count drops"},
            ])
            st.dataframe(eps_df, use_container_width=True, hide_index=True)
        with col_b:
            st.markdown("##### Effect of min_samples")
            ms_df = pd.DataFrame([
                {"min_samples": "Small (5-50)",    "Effect": "Everything is core, meaningless clusters"},
                {"min_samples": "Medium (250-300)","Effect": "Balance between noise and meaning"},
                {"min_samples": "Large (500+)",    "Effect": "Almost all noise, few clusters"},
            ])
            st.dataframe(ms_df, use_container_width=True, hide_index=True)

        st.markdown("##### 3-Step Search Strategy")
        ss_df = pd.DataFrame([
            {"Step": 1, "Condition": "≥5%, noise ≤30%",             "Result": "0 combinations"},
            {"Step": 2, "Condition": "≥2%, noise ≤50%",             "Result": "Few combinations"},
            {"Step": 3, "Condition": "Lowest noise + best balance", "Result": "Final parameters"},
        ])
        st.dataframe(ss_df, use_container_width=True, hide_index=True)

        note_box(
            "صورت تمرین دقیقاً پاسخ سؤال آخر را خواسته: نحوهٔ اثرگذاری hyperparameterها. "
            "این سه گام نشان می‌دهد که چطور پارامتر مناسب پیدا شد، نه اینکه از کجا آمده."
        )

        # SUPPLEMENTARY
        st.divider()
        st.markdown("### 🔬 Supplementary Path — Extended K-Means")
        st.caption("K-Means in extended feature space with PCA visualization")

        st.markdown("##### Supplementary K-Means vs Official")
        sup_cmp = pd.DataFrame([
            {"Group": "Sale",  "Rows": 545200, "Smallest Cluster": 3100, "Largest Cluster": 169473, "WCSS": 267433.7},
            {"Group": "Rent",  "Rows": 338688, "Smallest Cluster": 1823, "Largest Cluster": 88227,  "WCSS": 186129.7},
            {"Group": "Daily", "Rows": 17180,  "Smallest Cluster": 88,   "Largest Cluster": 4854,   "WCSS": 3368.4},
        ])
        st.dataframe(sup_cmp, use_container_width=True, hide_index=True)

        st.markdown("##### N10 — PCA Scatter: Sale")
        show_image("kmeans_pca_sales.png", "2D PCA projection of extended K-Means", width=1100)

        st.markdown("##### N11 — PCA Scatter: Rent")
        show_image("kmeans_pca_rent.png", "Note: C5 outlier cluster (expensive or noisy ads)", width=1100)

        st.markdown("##### N12 — PCA Scatter: Daily")
        show_image("kmeans_pca_daily.png", "Clusters appear as two parallel bands (cheap / expensive)", width=1100)

        st.markdown("##### N13 — WCSS Supplementary (k = 1..20)")
        show_image("wcss_supplementary.png", "Slope changes around k=5 · Vertical line at k=10", width=1100)

        st.markdown("##### Supplementary Cluster Profiles")
        sup_prof = pd.DataFrame([
            {"Group": "Sale",  "Largest Cluster": "C1 (apartment)", "Share": "31.1%", "Median Price": "2.2 B",   "Median Area": 76},
            {"Group": "Rent",  "Largest Cluster": "C2 (apartment)", "Share": "26.0%", "Median Price": "18.5 M",  "Median Area": 100},
            {"Group": "Daily", "Largest Cluster": "C1 (suite)",     "Share": "28.3%", "Median Price": "700,000", "Median Area": 90},
        ])
        st.dataframe(sup_prof, use_container_width=True, hide_index=True)

        # ALTERNATIVE PATH
        st.divider()
        st.markdown("### 🗺️ Alternative Path — Geographic DBSCAN on Daily")
        st.caption("Using raw longitude/latitude instead of UTM, 5 clusters found")

        st.markdown("##### N14 — DBSCAN Geographic (Daily)")
        show_image("dbscan_daily_geographic.png", "5 clusters + noise (grey)", width=1100)

        alt_df = pd.DataFrame([
            {"Cluster": "C0",    "Region": "Tehran & suburbs",        "Color": "Blue"},
            {"Cluster": "C1",    "Region": "Northern coast (Ramsar)", "Color": "Orange"},
            {"Cluster": "C2",    "Region": "Mashhad",                 "Color": "Dark orange"},
            {"Cluster": "C3",    "Region": "Rasht",                   "Color": "Light orange"},
            {"Cluster": "C4",    "Region": "Shiraz",                  "Color": "Green"},
            {"Cluster": "Noise", "Region": "—",                       "Color": "Light grey (6,648 rows)"},
        ])
        st.dataframe(alt_df, use_container_width=True, hide_index=True)

    # ========================================================
    # TAB 7 — LIMITATIONS
    # ========================================================
    with tabs[6]:
        st.markdown('<div class="subtab-title">محدودیت‌ها و جمع‌بندی</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "55.2%",   "label": "Daily DBSCAN noise", "warn": True},
            {"value": "18.13 GB","label": "Memory needed (sale)","warn": True},
            {"value": "3.03 GB", "label": "Available RAM",       "warn": True},
        ])

        st.markdown("##### DBSCAN Memory Estimation (Cell 112)")
        mem_df = pd.DataFrame([
            {"Group": "Sale",  "eps": 25, "Suggested min_samples": 11605, "Neighbor Entries (M)": 5499.9, "Memory (GB)": 88.00},
            {"Group": "Rent",  "eps": 10, "Suggested min_samples": 3457,  "Neighbor Entries (M)": 565.5,  "Memory (GB)": 9.05},
            {"Group": "Daily", "eps": 25, "Suggested min_samples": 386,   "Neighbor Entries (M)": 3.7,    "Memory (GB)": 0.06},
        ])
        st.dataframe(mem_df, use_container_width=True, hide_index=True)

        st.markdown("##### N15 — Memory Requirements")
        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=["Sale", "Rent", "Daily"],
            y=[88.0, 9.05, 0.06],
            marker_color=["#dc2626", "#f59e0b", "#10b981"],
            text=["88 GB", "9.05 GB", "0.06 GB"],
            textposition="outside",
        ))
        fig.add_hline(
            y=3.03, line_dash="dash", line_color="#dc2626",
            annotation_text="Available RAM (3.03 GB)",
            annotation_position="top right",
        )
        fig.update_layout(
            yaxis_title="Memory (GB)",
            font=dict(size=12),
            title_font=dict(size=16, color="#1e3a8a"),
            margin=dict(l=20, r=20, t=40, b=20),
            height=400,
        )
        st.plotly_chart(fig, use_container_width=True)

        note_box(
            "برای فروش در eps=10، تخمین BallTree نشان داد حدود ۱.۱۳ میلیارد همسایه لازم است "
            "که حدود ۱۸ گیگابایت حافظه می‌طلبد. RAM موجود فقط ۳ گیگابایت بود. "
            "این محدودیت سخت‌افزاری واقعی است، نه انتخاب ما. "
            "فقط روزانه در محدودهٔ اجرا بود که کامل اجرا شد.",
            kind="warn",
        )

        st.markdown("##### Remaining Limitations")
        lim_df = pd.DataFrame([
            {"Limitation": "Daily DBSCAN noise", "Value": "55%",         "Action": "Documented honestly"},
            {"Limitation": "Sale memory",        "Value": "18 GB",       "Action": "Only sample executed"},
            {"Limitation": "Placeholder values", "Value": "111111, 500", "Action": "No market label applied"},
            {"Limitation": "Cluster imbalance",  "Value": "C0 ≈ 80%",    "Action": "Imbalance documented"},
        ])
        st.dataframe(lim_df, use_container_width=True, hide_index=True)

        note_box(
            "اجرای DBSCAN کامل روی daily با eps=25 و min_samples=386 به ۵ خوشه با ۵۵٪ نویز رسید، نه ۳ خوشه. "
            "این محدودیت ذات داده است، نه انتخاب پارامتر. بعضی مقادیر مثل ۱۱۱۱۱۱ و ۵۰۰ در پروفایل خوشه‌ها "
            "دیده می‌شوند. ما این‌ها را به‌عنوان بازار ارزان یا لاکچری برچسب نزدیم — صریحاً گفتیم مشکوک‌اند.",
            kind="warn",
        )

        st.markdown("##### Summary — Requirements vs Answers")
        sum_df = pd.DataFrame([
            {"Requirement": "Feature selection",         "Our Answer": "5 criteria · 4 features · correlation analysis"},
            {"Requirement": "K-Means k=10 on UTM+price", "Our Answer": "3 independent models · two-panel scatter"},
            {"Requirement": "Choose k via WCSS",         "Our Answer": "4 metrics · consensus at k=4 · also accept k=10"},
            {"Requirement": "DBSCAN with 3 clusters",    "Our Answer": "3 geographic clusters · 9-14% noise"},
        ])
        st.dataframe(sum_df, use_container_width=True, hide_index=True)

        note_box(
            "پروژه چهار خواستهٔ صورت تمرین را برآورده کرد. پشت هر تصمیم یک دلیل دامنه یا فنی است، "
            "و هر محدودیت صادقانه مستند شده. برای سیستم توصیه‌گر، لایهٔ اول را جغرافیایی پیشنهاد می‌کنیم "
            "— خوشه‌های DBSCAN — و لایهٔ دوم را بر اساس قیمت و اندازه در هر خوشه."
        )


# ============================================================
# SECTION 3 — REGRESSION
# ============================================================
def regression_page():
    page_header(
        "💰 Regression",
        "Predict rent or sale price based on property features",
        key="back_regression",
    )
    st.info("This page will contain model training and evaluation (R², MAE, MSE).")
    st.write("Coming soon...")


# ============================================================
# ABOUT
# ============================================================
def about_page():
    page_header("ℹ️ About", "Project information", key="back_about")
    st.markdown("""
    **Divar Real Estate Analytics**

    - **Course:** Quera AI Bootcamp — Summer 2026
    - **Project:** Real estate ads analysis and prediction
    - **Stack:** Python, Streamlit, Plotly, scikit-learn, pandas
    """)


# ============================================================
# ROUTER
# ============================================================
PAGES = {
    "home":              home_page,
    "eda":               eda_page,
    "descriptive_stats": descriptive_stats_page,
    "hypothesis_tests":  hypothesis_tests_page,
    "clustering":        clustering_page,
    "regression":        regression_page,
    "about":             about_page,
}

PAGES[st.session_state.page]()