import os
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import glob


# ============================================================
# PAGE CONFIGURATION
# ============================================================
st.set_page_config(
    page_title="Divar Real Estate Analytics",
    page_icon="🏠",
    layout="wide",
    initial_sidebar_state="collapsed",
)


# ============================================================
# BASE DIRECTORY
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# ============================================================
# CUSTOM CSS
# ============================================================
st.markdown("""
<style>
    .main { background-color: #f7f9fc; }

    .supervisor-card {
        background: linear-gradient(135deg, #4c1d95 0%, #7c3aed 50%, #a855f7 100%);
        padding: 20px 20px; border-radius: 18px; color: #ffffff; text-align: center;
        box-shadow: 0 8px 24px rgba(124, 58, 237, 0.25); margin-bottom: 10px;
        height: 210px; min-height: 210px;
        display: grid; grid-template-rows: 50px 40px 22px 34px;
        align-content: center; justify-items: center; gap: 4px;
        overflow: hidden; border: 1px solid rgba(255, 255, 255, 0.15);
    }
    .supervisor-card .icon { font-size: 40px; line-height: 50px; height: 50px; display: flex; align-items: center; justify-content: center; }
    .supervisor-card .name { font-size: 20px; font-weight: 700; line-height: 1.2; height: 40px; max-height: 40px; width: 100%; padding: 0 4px; text-align: center; display: flex; align-items: flex-start; justify-content: center; overflow: hidden; overflow-wrap: break-word; word-break: normal; }
    .supervisor-card .role { font-size: 14px; line-height: 22px; height: 22px; opacity: 0.9; text-align: center; }
    .supervisor-card .email { font-size: 13px; line-height: 17px; height: 34px; max-height: 34px; opacity: 0.8; text-align: center; overflow: hidden; word-break: break-all; width: 100%; padding: 0 4px; }

    .member-card {
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 55%, #3b82f6 100%);
        padding: 18px 10px; border-radius: 16px; color: #ffffff; text-align: center;
        box-shadow: 0 6px 18px rgba(37, 99, 235, 0.22); margin-bottom: 10px;
        height: 220px; min-height: 220px;
        display: grid; grid-template-rows: 40px 36px 22px 34px;
        align-content: center; justify-items: center; gap: 4px;
        overflow: hidden; border: 1px solid rgba(255, 255, 255, 0.12);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .member-card:hover { transform: translateY(-3px); box-shadow: 0 10px 24px rgba(37, 99, 235, 0.32); }
    .member-card .icon { font-size: 32px; line-height: 40px; height: 40px; display: flex; align-items: center; justify-content: center; }
    .member-card .name { font-size: 14px; font-weight: 700; line-height: 1.25; height: 36px; max-height: 36px; width: 100%; padding: 0 4px; text-align: center; display: flex; align-items: flex-start; justify-content: center; overflow: hidden; overflow-wrap: break-word; word-break: normal; }
    .member-card .role { font-size: 12.5px; line-height: 22px; height: 22px; opacity: 0.9; text-align: center; }
    .member-card .email { font-size: 11px; line-height: 17px; height: 34px; max-height: 34px; opacity: 0.75; text-align: center; overflow: hidden; word-break: break-all; width: 100%; padding: 0 4px; }

    .stButton > button {
        width: 100%; height: 60px; font-size: 15px; border-radius: 12px;
        font-weight: 600; border: 1.5px solid #dbeafe; background-color: #ffffff;
        color: #1e3a8a; transition: all 0.2s ease;
    }
    .stButton > button:hover {
        border-color: #2563eb; background-color: #eff6ff; color: #1e40af;
        transform: translateY(-1px); box-shadow: 0 4px 12px rgba(37, 99, 235, 0.15);
    }

    .section-header {
        background: linear-gradient(90deg, #eff6ff 0%, #f7f9fc 100%);
        padding: 12px 18px; border-radius: 10px; margin: 28px 0 14px 0;
        border-left: 5px solid #2563eb; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
    }
    .section-header h3 { margin: 0; font-size: 16px; font-weight: 700; color: #1e3a8a; letter-spacing: 0.2px; }

    .stat-card {
        background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        border-left: 4px solid #2563eb; padding: 16px 18px;
        border-radius: 12px; box-shadow: 0 2px 8px rgba(37, 99, 235, 0.08);
    }
    .stat-card .value { font-size: 24px; font-weight: 800; color: #1e3a8a; line-height: 1.1; }
    .stat-card .label { font-size: 13px; color: #475569; margin-top: 6px; }
    .stat-card .sub { font-size: 11px; color: #64748b; margin-top: 2px; }
    .stat-card.warn { background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-left-color: #d97706; }
    .stat-card.warn .value { color: #92400e; }
    .stat-card.warn .label { color: #78350f; }

    .note-box {
        background: #eff6ff; border-left: 4px solid #3b82f6;
        padding: 14px 18px; border-radius: 10px; color: #1e3a8a;
        font-size: 14.5px; line-height: 1.9; margin: 14px 0;
        direction: rtl; text-align: right;
    }
    .note-box.warn { background: #fef3c7; border-left-color: #d97706; color: #78350f; }
    .note-box.info { background: #ecfeff; border-left-color: #0891b2; color: #155e75; }

    .subtab-title {
        font-size: 20px; font-weight: 700; color: #1e3a8a;
        margin: 6px 0 12px 0; direction: rtl; text-align: right;
    }

    h2 { color: #1e3a8a !important; font-weight: 700 !important; }
</style>
""", unsafe_allow_html=True)


# ============================================================
# SESSION STATE
# ============================================================
if "page" not in st.session_state:
    st.session_state.page = "home"


def go_to(page_name: str):
    st.session_state.page = page_name
    st.rerun()


# ============================================================
# SUPERVISOR
# ============================================================
SUPERVISOR = {
    "name": "Melika Molaei",
    "role": "Project Supervisor",
    "email": "melika.molaei@example.com",
}


# ============================================================
# GROUP MEMBERS
# ============================================================
MEMBERS = [
    {"name": "Haniyeh Rashidian",   "role": "Student", "email": "rashidianhaniyeh@gmail.com"},
    {"name": "Sina Bahramian",      "role": "Student", "email": "mohamad.sina1383@gmail.com"},
    {"name": "Fateme Bazgir",       "role": "Student", "email": "Fatemehbzg.fba@gmail.com"},
    {"name": "Fateme Shakibamehr",  "role": "Student", "email": "Fatemeshakiba1045@gmail.com"},
    {"name": "Pourya Einolghazaei", "role": "Student", "email": "pourya.civil@gmail.com"},
]


# ============================================================
# SHARED HEADER
# ============================================================
def page_header(title: str, subtitle: str = "", key: str = "back"):
    st.title(title)
    if subtitle:
        st.caption(subtitle)
    if st.button("⬅️ Back to Home", key=key):
        go_to("home")
    st.divider()


# ============================================================
# SHARED HELPERS
# ============================================================
def stat_cards(items, cols_per_row=None):
    if cols_per_row is None:
        cols_per_row = len(items)
    cols = st.columns(cols_per_row)
    for i, item in enumerate(items):
        with cols[i % cols_per_row]:
            warn_cls = " warn" if item.get("warn") else ""
            sub_html = f'<div class="sub">{item["sub"]}</div>' if item.get("sub") else ""
            st.markdown(f"""
            <div class="stat-card{warn_cls}">
                <div class="value">{item['value']}</div>
                <div class="label">{item['label']}</div>
                {sub_html}
            </div>
            """, unsafe_allow_html=True)


def note_box(text, kind=""):
    kind_cls = f" {kind}" if kind else ""
    st.markdown(f'<div class="note-box{kind_cls}">{text}</div>', unsafe_allow_html=True)


def show_image(filename, caption="", width=750):
    path = os.path.join(BASE_DIR, filename)
    if not os.path.exists(path):
        st.warning(f"⚠️ Image not found: `{filename}`")
        return
    col_left, col_center, col_right = st.columns([1, 5, 1])
    with col_center:
        st.image(path, caption=caption, width=width)

def show_test_images(prefix, width=900):
    """Shows all images matching `<prefix>*.jpg` or `<prefix>*.png`."""
    patterns = [
        os.path.join(BASE_DIR, f"{prefix}*.jpg"),
        os.path.join(BASE_DIR, f"{prefix}*.png"),
    ]
    files = []
    for p in patterns:
        files.extend(glob.glob(p))
    files = sorted(set(files))

    if not files:
        st.warning(f"⚠️ No images found matching: `{prefix}*.jpg` or `{prefix}*.png`")
        return

    for f in files:
        name = os.path.basename(f)
        col_l, col_c, col_r = st.columns([1, 5, 1])
        with col_c:
            st.image(f, caption=name, width=width)
# ============================================================
# HOME PAGE
# ============================================================
def home_page():
    st.title("🏠 Divar Real Estate Analytics")
    st.caption("Quera AI Bootcamp — Summer 2026 — Project 1")
    st.divider()

    st.subheader("🎓 Project Supervisor")
    sup_col1, sup_col2, sup_col3 = st.columns([1, 2, 1])
    with sup_col2:
        st.markdown(f"""
        <div class="supervisor-card">
            <div class="icon">👩‍🏫</div>
            <div class="name">{SUPERVISOR['name']}</div>
            <div class="role">{SUPERVISOR['role']}</div>
            <div class="email">📧 {SUPERVISOR['email']}</div>
        </div>
        """, unsafe_allow_html=True)

    st.divider()

    st.subheader("👥 Project Team")
    cols = st.columns(len(MEMBERS), gap="small")
    for i, m in enumerate(MEMBERS):
        with cols[i]:
            st.markdown(f"""
            <div class="member-card">
                <div class="icon">👤</div>
                <div class="name">{m['name']}</div>
                <div class="role">{m['role']}</div>
                <div class="email">📧 {m['email']}</div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown(
        '<div class="section-header"><h3>📁 Section 1 — Data</h3></div>',
        unsafe_allow_html=True,
    )
    if st.button("📈 EDA", use_container_width=True):
        go_to("eda")

    # ---- Section 2 (now 3 buttons) ----
    st.markdown(
        '<div class="section-header"><h3>🧪 Section 2 — Statistical Analysis</h3></div>',
        unsafe_allow_html=True,
    )
    c1, c2, c3 = st.columns(3)
    with c1:
        if st.button("📊 Descriptive Statistics", use_container_width=True):
            go_to("descriptive_stats")
    with c2:
        if st.button("🔬 Hypothesis Testing", use_container_width=True):
            go_to("hypothesis_tests")
    with c3:
        if st.button("⭐ Bonus Hypothesis Testing", use_container_width=True):
            go_to("bonus_hypothesis_tests")

    st.markdown(
        '<div class="section-header"><h3>🤖 Section 3 — Machine Learning</h3></div>',
        unsafe_allow_html=True,
    )
    c4, c5 = st.columns(2)
    with c4:
        if st.button("🎯 Clustering / Recommender", use_container_width=True):
            go_to("clustering")
    with c5:
        if st.button("💰 Regression", use_container_width=True):
            go_to("regression")

    st.divider()
    if st.button("ℹ️ About", use_container_width=True):
        go_to("about")


# ============================================================
# SECTION 1 — EDA
# ============================================================
def eda_page():
    page_header(
        "📈 EDA",
        "Exploratory Data Analysis — five key insights from the Divar dataset",
        key="back_eda",
    )

    # ========================================================
    # SECTION 1 — ONE DATASET, MANY MARKETS
    # ========================================================
    st.markdown('<div class="subtab-title">۱. یک مجموعه، چند بازار</div>', unsafe_allow_html=True)

    stat_cards([
        {"value": "1,000,000+", "label": "Total Ads",     "sub": "Divar real estate"},
        {"value": "59.76%",     "label": "Sale Share",    "sub": "of total"},
        {"value": "35.31%",     "label": "Rent Share",    "sub": "of total"},
        {"value": "19.09%",     "label": "Tehran Share",  "sub": "top city"},
    ])

    note_box(
        "از یک میلیون آگهی، <b>۵۹.۷۶٪</b> مربوط به فروش و <b>۳۵.۳۱٪</b> مربوط به اجاره است. "
        "تهران با سهم <b>۱۹.۰۹٪</b> بیشترین آگهی را دارد؛ بنابراین <b>بازارها و شهرها را جدا بررسی می‌کنیم</b>."
    )

    note_box(
        "<b>هشدار مهم:</b> تعداد آگهی، تعداد معامله نیست. "
        "این دیتاست فقط عرضه را نشون می‌ده، نه تقاضا یا معاملات واقعی.",
        kind="warn",
    )

    show_test_images("eda_step_01", width=1000)

    # ========================================================
    # SECTION 2 — WHICH PERIOD IS REPRESENTATIVE?
    # ========================================================
    st.markdown('<div class="subtab-title">۲. داده بیشتر نمایندهٔ کدام دوره است؟</div>', unsafe_allow_html=True)

    stat_cards([
        {"value": "98.57%", "label": "In 8 Months of 2024", "sub": "of dated ads", "warn": True},
        {"value": "Long Range", "label": "Recorded Period",  "sub": "but not uniform"},
    ])

    note_box(
        "با وجود بازهٔ ثبت‌شدهٔ طولانی، <b>۹۸.۵۷٪</b> آگهی‌های دارای تاریخ معتبر در "
        "<b>هشت ماه سال ۲۰۲۴</b> متمرکزند."
    )

    note_box(
        "<b>نکته:</b> تغییر تعداد آگهی‌ها به‌تنهایی نشان‌دهندهٔ رونق یا رکود بازار نیست. "
        "چون توزیع زمانی نامتوازنه، مقایسه‌ی ماهانه نیازمند احتیاطه."
    )

    show_test_images("eda_step_02", width=1000)

    # ========================================================
    # SECTION 3 — TYPICAL SIZE; WHY MEAN ISN'T ENOUGH
    # ========================================================
    st.markdown('<div class="subtab-title">۳. مساحت معمول؛ چرا میانگین کافی نیست؟</div>', unsafe_allow_html=True)

    stat_cards([
        {"value": "103 m²",   "label": "Median Size",  "sub": "typical building"},
        {"value": "4,441 m²", "label": "Mean Size",    "sub": "pulled by outliers", "warn": True},
    ])

    note_box(
        "میانهٔ مساحت <b>۱۰۳ متر مربع</b> است، اما میانگین به حدود <b>۴,۴۴۱ متر مربع</b> می‌رسد. "
        "دنبالهٔ راست و مقادیر بسیار بزرگ میانگین را بالا کشیده‌اند؛ "
        "تفسیر این مقادیر به <b>نوع ملک</b> نیاز دارد (ویلا و زمین با آپارتمان یکی نیست)."
    )

    show_test_images("eda_step_03", width=1000)

    # ========================================================
    # SECTION 4 — PRICE TAILS
    # ========================================================
    st.markdown('<div class="subtab-title">۴. قیمت‌ها؛ دنباله‌ای که میانگین را تغییر می‌دهد</div>', unsafe_allow_html=True)

    note_box(
        "توزیع قیمت فروش، اجاره و ودیعه <b>چولگی شدید به راست</b> دارد. "
        "میانه برای توصیف مقدار معمول، کمتر از میانگین تحت تأثیر مقادیر افراطی قرار می‌گیرد. "
        "مبالغ بسیار بزرگ نیازمند بررسی‌اند (خطای ثبت یا ملک خاص)."
    )

    note_box(
        "<b>راهنمای نمودارها:</b> سمت چپ فقط مقادیر مثبت تا صدک ۹۹ را نشون می‌ده؛ "
        "سمت راست تمام مقادیر مثبت پس از تبدیل log10. "
        "محدودکردن نمایش، <b>حذف داده از آمار نیست</b>؛ و تبدیل لگاریتمی <b>تضمین نرمال‌شدن نیست</b>.",
        kind="info",
    )

    note_box(
        "<b>واحد قیمت:</b> واحد خام دیتاست (تومان یا ریال در فایل تأیید نشده).",
        kind="warn",
    )

    show_test_images("eda_step_04", width=1000)

    # ========================================================
    # SECTION 5 — DAILY RATES QUALITY
    # ========================================================
    st.markdown('<div class="subtab-title">۵. نرخ‌های روزانه چقدر قابل استفاده‌اند؟</div>', unsafe_allow_html=True)

    stat_cards([
        {"value": "667",     "label": "Ads with Multiple Rates", "sub": "at least 2 positive"},
        {"value": ">10×",    "label": "Max/Min Ratio",           "sub": "requires investigation", "warn": True},
    ])

    note_box(
        "نرخ روز عادی بیشتر از نرخ آخر هفته و مناسبت‌ها ثبت شده است. "
        "در <b>۶۶۷ آگهی</b> دارای حداقل دو نرخ مثبت، نسبت بیشترین نرخ به کمترین نرخ <b>بیشتر از ۱۰</b> است؛ "
        "این اختلاف نیازمند بررسی است — احتمالاً خطای ثبت یا تفاوت ماهیت ملک."
    )

    show_test_images("eda_step_05", width=1000)

    # ========================================================
    # DATA QUALITY CARDS (end of EDA)
    # ========================================================
    st.divider()
    st.markdown("### 🎯 کیفیت داده — سه شاخص کلیدی", unsafe_allow_html=True)

    stat_cards([
        {"value": "3.67%",   "label": "Unknown City Category", "sub": "missing city slug", "warn": True},
        {"value": "34.44%",  "label": "Missing Coordinates",    "sub": "at least one lat/lon", "warn": True},
        {"value": "1,175",   "label": "Floor Inconsistencies",  "sub": "floor > total_floors", "warn": True},
    ])

    note_box(
        "این سه شاخص نشون می‌ده که داده خام نیازمند پاک‌سازی جدی است. "
        "در بخش‌های بعدی (Clustering و Regression) این مشکلات به روش‌های مختلف مدیریت شدن: "
        "حذف ردیف‌های ناقص، بازسازی مختصات از محله، و فلگ کردن ناسازگاری‌ها."
    )

    note_box(
        "<b>گام بعدی:</b> آماده‌سازی داده — پاک‌سازی ارقام فارسی، تبدیل بولی‌ها، "
        "بازسازی مقادیر missing با روش‌های مکانی، و مهندسی ویژگی.",
        kind="info",
    )


# ============================================================
# SECTION 2 — DESCRIPTIVE STATS
# ============================================================
def descriptive_stats_page():
    page_header(
        "📊 Descriptive Statistics",
        "Nine-step exploration of Divar real estate data",
        key="back_desc",
    )

    tabs = st.tabs([
        "📌 Overview",
        "🏷️ Category & Time",
        "💰 Prices",
        "📍 Geography",
        "🔗 Correlation",
        "✨ Amenities",
    ])

    # ========================================================
    # TAB 1 — OVERVIEW
    # ========================================================
    with tabs[0]:
        st.markdown('<div class="subtab-title">مرور کلی تحلیل توصیفی</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "9",       "label": "Analysis Steps",   "sub": "sequential exploration"},
            {"value": "1M+",     "label": "Total Ads",        "sub": "Divar dataset"},
            {"value": "3",       "label": "Price Types",      "sub": "sale · rent · deposit"},
            {"value": "404",     "label": "Cities",           "sub": "geographic span"},
        ])

        note_box(
            "این تحلیل ۹ مرحله‌ای یک مسیر رو دنبال می‌کنه: از <b>شناخت ترکیب دسته‌بندی</b> شروع می‌کنیم، "
            "سپس <b>سال ساخت</b> و <b>الگوی زمانی آگهی‌ها</b> رو بررسی می‌کنیم، "
            "بعد به <b>قیمت</b> می‌رسیم، <b>جغرافیا</b> رو وارد داستان می‌کنیم، "
            "و در نهایت <b>روابط بین متغیرها</b> و <b>پراکندگی امکانات</b> رو می‌بینیم."
        )

        note_box(
            "<b>اصل راهنما:</b> در هر مرحله، میانگین و میانه رو کنار هم می‌بینیم. "
            "چون در داده‌های املاک، دنباله‌ی راست توزیع، میانگین رو به‌شدت تحت تأثیر قرار می‌ده. "
            "میانه معیار قابل‌اعتمادتری برای توصیف «مقدار معمول» است.",
            kind="info",
        )

    # ========================================================
    # TAB 2 — CATEGORY & TIME
    # ========================================================
    with tabs[1]:
        # ---- Section 1: Category Distribution ----
        st.markdown('<div class="subtab-title">آمار توصیفی ۱ — ترکیب دسته‌بندی ملک</div>', unsafe_allow_html=True)

        note_box(
            "این نمودار تعداد و سهم دسته‌بندی‌های مختلف ملک را نشان می‌دهد و مشخص می‌کند "
            "ترکیب داده‌های ما از چه گروه‌هایی تشکیل شده است.<br><br>"
            "شناخت این ترکیب اهمیت دارد؛ زیرا <b>رفتار قیمت و اجاره در دسته‌های مختلف ملک لزوماً یکسان نیست</b>.<br><br>"
            "بنابراین در ادامه تحلیل، <b>نوع ملک</b> را به‌عنوان یکی از عوامل مهم در بررسی تفاوت‌های بازار در نظر می‌گیریم."
        )

        show_test_images("tsf1", width=950)

        st.divider()

        # ---- Section 2: Construction Year ----
        st.markdown('<div class="subtab-title">آمار توصیفی ۲ — سال ساخت</div>', unsafe_allow_html=True)

        note_box(
            "یکی از ویژگی‌های مهم هر ملک، <b>سال ساخت</b> آن است. "
            "در این نمودار، فراوانی سال‌های ساخت ثبت‌شده در آگهی‌ها را بررسی می‌کنیم "
            "تا تصویری از قدمت ساختمان‌های موجود در مجموعه داده به دست آوریم.<br><br>"
            "توجه داریم که برخی مقادیر به صورت بازه‌ای مانند «قبل از ۱۳۷۰» ثبت شده‌اند "
            "و در نمودار با <b>سال مرزی</b> نمایش داده می‌شوند.<br><br>"
            "این بررسی مقدمه‌ای برای شناخت ارتباط ویژگی‌های ساختمان با قیمت است."
        )

        show_test_images("tsf2", width=950)

        st.divider()

        # ---- Section 3: Monthly Ads ----
        st.markdown('<div class="subtab-title">آمار توصیفی ۳ — تعداد آگهی‌ها در ماه‌های مختلف</div>', unsafe_allow_html=True)

        st.markdown("###### بخش الف — نمای کلی")
        note_box(
            "تا اینجا ویژگی‌های خود املاک را بررسی کردیم؛ حالا زمان ثبت آگهی‌ها را وارد تحلیل می‌کنیم. "
            "این نمودار تعداد آگهی‌های فروش و اجاره را در ماه‌های مختلف نشان می‌دهد.<br><br>"
            "با مشاهده روند زمانی می‌توان دوره‌های افزایش یا کاهش تعداد آگهی‌های ثبت‌شده را شناسایی کرد.<br><br>"
            "<b>هشدار مهم:</b> تعداد آگهی‌ها لزوماً معادل حجم معاملات واقعی بازار نیست و می‌تواند تحت تأثیر "
            "میزان فعالیت کاربران و ترکیب داده‌های جمع‌آوری‌شده قرار بگیرد."
        )

        st.markdown("###### بخش ب — مقایسه ماه تقویمی در سال‌های مختلف")
        note_box(
            "برای بررسی دقیق‌تر تغییرات زمانی، تعداد آگهی‌ها را بر اساس <b>ماه تقویمی</b> "
            "و در <b>سال‌های مختلف</b> کنار هم قرار داده‌ایم.<br><br>"
            "این مقایسه کمک می‌کند ببینیم آیا در ماه‌های مشخصی از سال، تعداد آگهی‌های ثبت‌شده "
            "الگوی مشابهی دارد یا تغییرات سالانه متفاوت است.<br><br>"
            "<b>محدودیت:</b> برای نتیجه‌گیری درباره فصل‌مندی بازار، باید تفاوت تعداد سال‌های موجود "
            "و ترکیب داده‌ها را نیز در نظر بگیریم."
        )

        st.markdown("###### بخش پ — مقیاس لگاریتمی برای مقایسه نسبی")
        note_box(
            "در این مرحله، تعداد آگهی‌های فروش و اجاره را در یک <b>مقیاس لگاریتمی</b> بررسی می‌کنیم.<br><br>"
            "استفاده از مقیاس لگاریتمی کمک می‌کند اختلاف‌های بزرگ میان تعداد آگهی‌ها، "
            "نمایش روند هر دو گروه را دشوار نکند.<br><br>"
            "این نمودار امکان مقایسه <b>تغییرات نسبی</b> دو نوع آگهی را در بازه‌ی زمانی مشترک فراهم می‌کند. "
            "تمرکز ما در این بخش بر <b>تغییرات تعداد آگهی‌های ثبت‌شده</b> است، نه بر قیمت یا حجم معاملات قطعی."
        )

        show_test_images("tsf3", width=950)

    # ========================================================
    # TAB 3 — PRICES
    # ========================================================
    with tabs[2]:
        # ---- Section 4: Sale price by category ----
        st.markdown('<div class="subtab-title">آمار توصیفی ۴ — توزیع قیمت فروش در دسته‌های ملک</div>', unsafe_allow_html=True)

        note_box(
            "پس از شناخت ترکیب آگهی‌ها، به سراغ یکی از مهم‌ترین ویژگی‌های اقتصادی آن‌ها "
            "یعنی <b>قیمت فروش</b> می‌رویم. در این نمودار، توزیع قیمت فروش در دسته‌بندی‌های مختلف ملک مقایسه شده است.<br><br>"
            "نمایش <b>لگاریتمی</b> قیمت کمک می‌کند اختلاف مقیاس میان گروه‌ها بهتر قابل مشاهده باشد.<br><br>"
            "این مقایسه نشان می‌دهد که <b>نوع ملک</b> می‌تواند یکی از ابعاد مهم در تحلیل تفاوت قیمت‌ها باشد. "
            "در تفسیر نمودار باید به <b>میانه، پراکندگی و هم‌پوشانی توزیع گروه‌ها</b> توجه کنیم، نه فقط به بالاترین مقدار."
        )

        show_test_images("tsf4", width=950)

        st.divider()

        # ---- Section 6: Rent trend ----
        st.markdown('<div class="subtab-title">آمار توصیفی ۶ — روند اجاره نقدی در طول زمان</div>', unsafe_allow_html=True)

        note_box(
            "بعد از بررسی پراکندگی مکانی، حالا به سراغ تغییرات <b>قیمت اجاره در طول زمان</b> می‌رویم.<br><br>"
            "در این نمودار، <b>میانگین و میانه اجاره نقدی</b> آگهی‌ها بر اساس ماه ثبت آگهی نمایش داده شده است.<br><br>"
            "مقایسه میانگین و میانه اهمیت دارد؛ زیرا میانگین می‌تواند تحت تأثیر مقادیر بزرگ قرار بگیرد، "
            "در حالی که میانه موقعیت مرکزی داده‌ها را از زاویه‌ی دیگری نشان می‌دهد."
        )

        note_box(
            "<b>روش:</b> برای جلوگیری از تأثیر مقادیر بسیار بزرگ، مقادیر بالاتر از <b>صدک ۹۹</b> حذف شده‌اند.<br><br>"
            "<b>محدودیت:</b> این روند بیانگر <b>اجاره نقدی ثبت‌شده در آگهی‌هاست</b> "
            "و <b>مبلغ ودیعه را در قالب اجاره معادل محاسبه نمی‌کند</b>.",
            kind="warn",
        )

        show_test_images("tsf6", width=950)

        st.divider()

        # ---- Section 7: Real vs nominal price ----
        st.markdown('<div class="subtab-title">آمار توصیفی ۷ — قیمت اسمی و تعدیل‌شده با تورم</div>', unsafe_allow_html=True)

        note_box(
            "برای بررسی تغییرات قیمت در سال‌های مختلف، صرفاً مقایسه‌ی اعداد ثبت‌شده کافی نیست؛ "
            "زیرا <b>ارزش پول در طول زمان تغییر می‌کند</b>.<br><br>"
            "در این بخش، قیمت‌های <b>اسمی</b> را در کنار قیمت‌های <b>تعدیل‌شده با شاخص تورم</b> بررسی می‌کنیم. "
            "مقایسه میانگین و میانه نیز کمک می‌کند تأثیر آگهی‌های با قیمت بالا را بهتر بشناسیم."
        )

        note_box(
            "<b>محدودیت مهم:</b> از آنجا که ترکیب شهرها، متراژها و انواع ملک در سال‌های مختلف ممکن است متفاوت باشد، "
            "این مقایسه را نباید به‌عنوان <b>بازده واقعی سرمایه‌گذاری</b> در بازار مسکن تفسیر کرد.",
            kind="warn",
        )

        show_test_images("tsf7", width=950)

    # ========================================================
    # TAB 4 — GEOGRAPHY
    # ========================================================
    with tabs[3]:
        st.markdown('<div class="subtab-title">آمار توصیفی ۵ — نقشه تراکم آگهی‌ها</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "404",  "label": "Cities",           "sub": "in dataset"},
            {"value": "Tehran", "label": "Top City",        "sub": "~19% of ads", "warn": False},
            {"value": "34.44%","label": "Missing Coords",   "sub": "at least one", "warn": True},
        ])

        note_box(
            "تا اینجا داده‌ها را از نظر ویژگی‌های ملک، دسته‌بندی و قیمت بررسی کردیم. "
            "اکنون <b>موقعیت جغرافیایی</b> را وارد داستان می‌کنیم.<br><br>"
            "نقشه تراکم آگهی‌ها نشان می‌دهد نقاط ثبت‌شده در داده‌ها در چه مناطقی تمرکز بیشتری دارند. "
            "این تصویر به ما کمک می‌کند پراکندگی مکانی آگهی‌ها را بهتر درک کنیم و "
            "تفاوت میان مناطق پرتراکم و کم‌تراکم را مشاهده کنیم."
        )

        note_box(
            "<b>هشدار:</b> این نقشه بر اساس مختصات موجود در نمونه‌ی انتخاب‌شده است و "
            "مختصات <b>تخمینی</b> نیز ممکن است در آن حضور داشته باشند. "
            "نزدیک به یک‌سوم رکوردها حداقل یک مختصات گمشده دارند.",
            kind="warn",
        )

        show_test_images("tsf5", width=1000)

    # ========================================================
    # TAB 5 — CORRELATION
    # ========================================================
    with tabs[4]:
        st.markdown('<div class="subtab-title">آمار توصیفی ۸ — ماتریس همبستگی</div>', unsafe_allow_html=True)

        note_box(
            "پس از بررسی جداگانه ویژگی‌ها و روند قیمت، اکنون <b>روابط میان متغیرهای عددی</b> را بررسی می‌کنیم.<br><br>"
            "ماتریس همبستگی نشان می‌دهد هر جفت از ویژگی‌ها تا چه اندازه با یکدیگر ارتباط آماری دارند. "
            "در این تحلیل از دو معیار <b>پیرسون</b> و <b>اسپیرمن</b> استفاده شده است:<br><br>"
            "• <b>پیرسون:</b> ارتباط خطی را بررسی می‌کند.<br>"
            "• <b>اسپیرمن:</b> رابطه بر اساس <b>رتبه‌ی داده‌ها</b> را می‌سنجد."
        )

        note_box(
            "این مرحله به ما کمک می‌کند روابط احتمالی میان ویژگی‌های ملک را شناسایی کنیم "
            "و شناخت بهتری از داده‌ها برای تحلیل‌های بعدی به دست آوریم."
        )

        note_box(
            "<b>نکته‌ی کلیدی:</b> همبستگی به معنای <b>رابطه‌ی علت و معلولی</b> نیست. "
            "حتی همبستگی قوی بین دو متغیر، ممکن است ناشی از یک متغیر پنهان سوم باشد.",
            kind="warn",
        )

        st.markdown("###### Pearson Correlation")
        show_test_images("tsf8", width=1000)

        st.markdown("###### Spearman Correlation")
        show_test_images("tsf9", width=1000)

    # ========================================================
    # TAB 6 — AMENITIES
    # ========================================================
    with tabs[5]:
        st.markdown('<div class="subtab-title">آمار توصیفی ۹ — پراکندگی امکانات</div>', unsafe_allow_html=True)

        st.markdown("###### بخش الف — سهم امکانات از کل آگهی‌های هر شهر")
        note_box(
            "در نمودار قبلی تعداد آگهی‌های دارای امکانات را دیدیم؛ اما شهرهای بزرگ‌تر "
            "طبیعتاً می‌توانند تعداد آگهی بیشتری داشته باشند.<br><br>"
            "برای مقایسه‌ی منصفانه‌تر، این بار <b>سهم آگهی‌های دارای هر امکان از کل آگهی‌های همان شهر</b> "
            "را بررسی می‌کنیم. این شاخص به ما کمک می‌کند <b>تمرکز نسبی امکانات</b> را میان شهرها مقایسه کنیم."
        )

        note_box(
            "<b>معیار ورود به تحلیل:</b> فقط شهرهایی با <b>حداقل ۵۰۰ آگهی</b> در تحلیل درصدی وارد شده‌اند "
            "تا مقایسه بر پایه‌ی نمونه‌های بسیار کوچک انجام نشود. "
            "بنابراین این نمودار <b>مکمل</b> نمودار تعداد است، نه جایگزین آن.",
            kind="info",
        )

        show_test_images("tsf9-1", width=1000)

        st.divider()

        st.markdown("###### بخش ب — نقشه‌ی حرارتی: امکانات در ۱۵ شهر پرتعداد")
        note_box(
            "برای اینکه بتوانیم چندین شهر و چندین نوع امکان را هم‌زمان بررسی کنیم، "
            "از <b>نقشه‌ی حرارتی</b> استفاده کرده‌ایم. هر خانه نشان‌دهنده‌ی <b>تعداد آگهی‌های دارای یک امکان در یک شهر</b> است.<br><br>"
            "شدت رنگ‌ها امکان شناسایی سریع مقادیر بیشتر و کمتر را فراهم می‌کند. "
            "این تصویر نمایی کلی از توزیع امکانات در <b>۱۵ شهر دارای بیشترین تعداد آگهی</b> ارائه می‌دهد."
        )

        note_box(
            "<b>نکته:</b> مقادیر این نقشه <b>تعداد</b> هستند و برای مقایسه‌ی رواج امکانات "
            "باید به نمودار <b>درصدی</b> قبلی نیز مراجعه کنیم.",
            kind="warn",
        )

        show_test_images("tsf9-2", width=1000)

        st.divider()

        st.markdown("###### بخش پ — نقشه‌ی حرارتی: امکانات در ۲۰ محله پرتعداد تهران")
        note_box(
            "در آخرین مرحله از تحلیل امکانات، تعداد آگهی‌های دارای امکانات مختلف را "
            "برای <b>۲۰ محله پرتعداد تهران</b> کنار هم قرار می‌دهیم.<br><br>"
            "این نقشه‌ی حرارتی به ما امکان می‌دهد چند ویژگی و چند محله را به صورت هم‌زمان مقایسه کنیم. "
            "با مشاهده‌ی الگوی رنگ‌ها می‌توان نقاط تمرکز هر امکان را شناسایی کرد و تفاوت‌های مکانی را در یک نگاه دید.<br><br>"
            "این تصویر جمع‌بندی بخش تحلیل امکانات است و در کنار نمودارهای تعداد و درصد، "
            "درک کامل‌تری از پراکندگی امکانات رفاهی ارائه می‌دهد."
        )

        show_test_images("tsf9-3", width=1000)
        show_test_images("tsf9-4", width=1000)
        show_test_images("tsf9-5", width=1000)


# ============================================================
# SECTION 2 — HYPOTHESIS TESTING (main)
# ============================================================
def hypothesis_tests_page():
    page_header(
        "🔬 Hypothesis Testing",
        "Four statistical tests on real estate market assumptions",
        key="back_hyp",
    )

    tabs = st.tabs([
        "📌 Overview",
        "🏙️ Test 1 — Metro Size",
        "🏗️ Test 2 — Old vs New",
        "📜 Test 3 — Business Deed",
        "✨ Test 4 — Luxury Amenities",
        "📋 Summary",
    ])

    # ========================================================
    # TAB 1 — OVERVIEW
    # ========================================================
    with tabs[0]:
        st.markdown('<div class="subtab-title">مرور آزمون‌های فرض</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "4",             "label": "Hypotheses Tested",  "sub": "on market assumptions"},
            {"value": "α = 0.05",      "label": "Significance Level", "sub": "standard threshold"},
            {"value": "Mann-Whitney",  "label": "Main Method",        "sub": "non-parametric U test"},
            {"value": "~1M",           "label": "Sample Size",        "sub": "full dataset"},
        ])

        st.markdown("##### Four Hypotheses at a Glance")
        overview_df = pd.DataFrame([
            {"ID": "T1", "Question": "Is building size smaller in metropolises?", "Method": "Mann-Whitney U (one-sided)", "Result": "Reject H₀"},
            {"ID": "T2", "Question": "Are old-construction buildings larger?",    "Method": "Mann-Whitney U (one-sided)", "Result": "Fail to reject"},
            {"ID": "T3", "Question": "Does business deed affect sale price?",     "Method": "Mann-Whitney U (two-sided)", "Result": "Reject H₀"},
            {"ID": "T4", "Question": "Do luxury amenities raise price?",          "Method": "Mann-Whitney U (one-sided)", "Result": "Reject H₀"},
        ])
        st.dataframe(overview_df, use_container_width=True, hide_index=True)

        note_box(
            "در همه‌ی آزمون‌ها فرض نرمال بودن به‌شدت رد شد. متراژ چولگی ۵۶ و کشیدگی بالای ۳۰۰۰ داره. "
            "قیمت‌ها هم حتی پس از لگاریتم‌گیری نرمال نیستن (شاپیرو-ویلک W ≈ ۰.۶۸). "
            "به همین دلیل از آزمون <b>Mann-Whitney U</b> استفاده می‌کنیم که به توزیع حساس نیست."
        )

        note_box(
            "نکته مهم درباره‌ی تفسیر: در دیتاست‌های بزرگ، p-value تقریباً همیشه معنادار می‌شه. "
            "پس ما علاوه بر p-value، <b>اندازه‌ی اثر</b> رو هم گزارش می‌کنیم. "
            "معیار ما: احتمال اینکه یک نمونه‌ی تصادفی از گروه اول بزرگ‌تر از گروه دوم باشد. "
            "اگر این عدد حدود ۵۰٪ باشه، یعنی تفاوت در عمل ناچیزه.",
            kind="info",
        )

    # ========================================================
    # TAB 2 — TEST 1
    # ========================================================
    with tabs[1]:
        st.markdown('<div class="subtab-title">آزمون ۱ — متراژ در کلان‌شهرها کوچک‌تر است؟</div>', unsafe_allow_html=True)

        st.markdown("##### Hypothesis")
        note_box(
            "<b>H₀:</b> توزیع متراژ در کلان‌شهر و شهر کوچک یکسان است.<br>"
            "<b>H₁:</b> متراژ کلان‌شهرها <b>کوچک‌تر</b> از شهرهای کوچک است.<br>"
            "<b>نوع آزمون:</b> Mann-Whitney U یک‌طرفه (one-sided)"
        )

        stat_cards([
            {"value": "48.3%", "label": "Metropolis Ads", "sub": "share of total"},
            {"value": "51.7%", "label": "Small City Ads", "sub": "share of total"},
            {"value": "~1M",   "label": "Total Sample",   "sub": "balanced halves"},
        ])

        st.markdown("##### Distribution of Ads by City Type")
        dist_df = pd.DataFrame([
            {"City Type": "Metropolis", "Share": 48.3},
            {"City Type": "Small City", "Share": 51.7},
        ])
        fig = px.bar(
            dist_df, x="City Type", y="Share",
            color="City Type",
            color_discrete_map={"Metropolis": "#2563eb", "Small City": "#94a3b8"},
            text="Share",
        )
        fig.update_traces(texttemplate="%{text}%", textposition="outside")
        fig.update_layout(
            yaxis_title="Share of Ads (%)",
            yaxis_range=[0, 60],
            height=380,
            margin=dict(l=20, r=20, t=20, b=20),
            showlegend=False,
        )
        st.plotly_chart(fig, use_container_width=True)

        note_box(
            "آگهی‌ها تقریباً بین دو گروه نصف‌نصف‌اند: ۵۱.۷٪ شهر کوچک و ۴۸.۳٪ کلان‌شهر. "
            "پس مقایسه از نظر حجم نمونه منصفانه است."
        )

        st.markdown("##### Chi-Square: City Type × Property Type")
        note_box(
            "رابطه‌ی نوع شهر با نوع ملک (آپارتمان، ویلا، مغازه و...) معنادار است (<b>p ≈ 0</b>). "
            "یعنی ترکیب آگهی‌ها در کلان‌شهر و شهر کوچک فرق دارد — مثلاً آپارتمان در کلان‌شهر سهم بیشتری دارد."
        )

        st.markdown("##### Images — Histogram, Q-Q, and Results")
        show_test_images("azmoon1", width=900)

        note_box(
            "متراژ به‌هیچ‌وجه نرمال نیست. چولگی ۵۶ و کشیدگی بیش از ۳۰۰۰. "
            "بعضی آگهی‌ها متراژ ۱۰ میلیون متر ثبت کرده‌اند (خطای ورودی). "
            "آزمون شاپیرو هم نرمال بودن را رد می‌کند، پس آزمون ناپارامتری مان‌ویتنی انتخاب شد."
        )

        st.markdown("##### Decision")
        note_box(
            "<b>p ≈ 3.8 × 10⁻⁴⁵ → فرض صفر رد می‌شود.</b><br>"
            "متراژ آپارتمان‌های کلان‌شهرها از نظر آماری کوچک‌تر است."
        )

        note_box(
            "<b>نکته‌ی مهم برای روایت:</b> اندازه‌ی اثر کوچک است. "
            "احتمال اینکه یک ملک کلان‌شهر بزرگ‌تر از یک ملک شهر کوچک باشد حدود <b>۴۹٪</b> است "
            "(یعنی تقریباً شیر یا خط) و ضریب رتبه‌ای ‎−۰.۰۲‎ است. "
            "با نزدیک به یک میلیون آگهی، حتی تفاوت ناچیز هم «معنادار» می‌شود.<br><br>"
            "<b>جمع‌بندی صادقانه:</b> کلان‌شهرها کمی کوچک‌ترند، ولی تفاوت در عمل بسیار ناچیز است.",
            kind="warn",
        )

    # ========================================================
    # TAB 3 — TEST 2
    # ========================================================
    with tabs[2]:
        st.markdown('<div class="subtab-title">آزمون ۲ — ساختمان‌های قدیمی بزرگ‌ترند؟</div>', unsafe_allow_html=True)

        st.markdown("##### Hypothesis")
        note_box(
            "<b>H₀:</b> توزیع متراژ در خانه‌های قدیمی و نوساز یکسان است.<br>"
            "<b>H₁:</b> متراژ ملک‌های قدیمی (قبل از ۱۳۹۶) <b>بیشتر</b> از نوساز است.<br>"
            "<b>نوع آزمون:</b> Mann-Whitney U یک‌طرفه (one-sided)"
        )

        stat_cards([
            {"value": "۱۳۶۹ – ۱۴۰۳", "label": "Year Range",  "sub": "Shamsi"},
            {"value": "۱۳۹۵",         "label": "Median Year", "sub": "Shamsi"},
            {"value": "~۱۸٪",         "label": "Missing Year","sub": "excluded from test"},
        ])

        st.markdown("##### Data Cleaning")
        note_box(
            "سال‌ها با ارقام فارسی ثبت شده بودند (مثل «۱۳۸۴») و گاهی به شکل «قبل از ۱۳۷۰». "
            "آن‌ها را به عدد تبدیل کردیم، «قبل از ۱۳۷۰» را ۱۳۶۹ گرفتیم و حدود ۱۸٪ آگهی‌ها که سال ساخت نداشتند کنار رفتند."
        )

        st.markdown("##### Images — Histogram, Q-Q, and Results")
        show_test_images("azmoon2", width=900)

        note_box(
            "توزیع سال ساخت نرمال نیست و کمی به سمت ساخت‌های جدید کشیده شده "
            "(چولگی حدود ‎−۱.۰). تعداد ساختمان‌های نوساز بیشتر است. "
            "توزیع متراژ هم مثل آزمون قبل، چولگی شدید دارد."
        )

        st.markdown("##### Decision")
        note_box(
            "<b>p = 1.0 → شواهد کافی برای رد H₀ نیست.</b>"
        )

        note_box(
            "<b>نکته‌ی جالب برای روایت:</b> این p نشان می‌دهد فرضیه‌ی ما <b>جهتش اشتباه</b> بوده. "
            "احتمال اینکه متراژ یک ملک قدیمی بیشتر از ملک نوساز باشد حدود <b>۳۹٪</b> است "
            "و ضریب رتبه‌ای ‎−۰.۲۲‎ است. داده می‌گوید ملک‌های <b>جدیدتر</b> معمولاً بزرگ‌ترند "
            "(با اثر کوچک تا متوسط).<br><br>"
            "<b>پیشنهاد:</b> در ارائه توضیح بدید که آزمون یک‌طرفه‌ی ما جهت اشتباهی داشت. "
            "اگر آزمون در جهت less یا دوطرفه اجرا شود، نتیجه معنادار خواهد بود.",
            kind="warn",
        )

    # ========================================================
    # TAB 4 — TEST 3
    # ========================================================
    with tabs[3]:
        st.markdown('<div class="subtab-title">آزمون ۳ — سند تجاری روی قیمت اثر دارد؟</div>', unsafe_allow_html=True)

        st.markdown("##### Hypothesis")
        note_box(
            "<b>H₀:</b> سند تجاری به قیمت فروش ربطی ندارد.<br>"
            "<b>H₁:</b> سند تجاری به قیمت فروش ربط <b>دارد</b>.<br>"
            "<b>نوع آزمون:</b> Mann-Whitney U دوطرفه (two-sided)"
        )

        stat_cards([
            {"value": "3.5%",   "label": "Ads with Deed", "sub": "of total dataset"},
            {"value": "14,117", "label": "With Deed",     "sub": "after cleaning"},
            {"value": "14,255", "label": "Without Deed",  "sub": "after cleaning"},
            {"value": "~28K",   "label": "Final Sample",  "sub": "balanced halves"},
        ])

        st.markdown("##### Description of Data")
        note_box(
            "فقط حدود ۳.۵٪ آگهی‌ها وضعیت سند تجاری دارند. بعد از حذف قیمت‌های صفر و خارج از حد، "
            "حدود ۲۸ هزار آگهی ماند: ۱۴,۱۱۷ با سند و ۱۴,۲۵۵ بدون سند — یعنی تقریباً نصف‌نصف."
        )

        st.markdown("##### Images — Box Plot, Histogram, KDE, and Results")
        show_test_images("azmoon3", width=900)

        note_box(
            "در مقیاس عادی چند قیمت بسیار بالا نمودار را له می‌کنند و فقط یک جعبه‌ی فشرده می‌بینیم. "
            "مقیاس لگاریتمی تصویر خواناتری می‌دهد و تفاوت بین دو گروه را در میانه نشان می‌دهد. "
            "در مقیاس لگاریتمی دو توزیع شکل مشابهی دارند و آگهی‌های دارای سند کمی به راست متمایل‌اند."
        )

        note_box(
            "آزمون نرمالی: هم قیمت خام و هم لگاریتم آن در هر دو گروه نرمال نیستند. "
            "لگاریتم هم مشکل را حل نمی‌کند (W ≈ ۰.۶۸)، پس باز هم مان‌ویتنی انتخاب می‌شود.",
            kind="info",
        )

        st.markdown("##### Decision")
        note_box(
            "<b>p ≈ 1 × 10⁻⁶¹ → فرض صفر رد می‌شود.</b><br>"
            "قیمت دو گروه تفاوت معنادار دارد و جهت آن به نفع آگهی‌های دارای سند است."
        )

        note_box(
            "<b>نکته‌ی روایت:</b> از U گزارش‌شده حساب می‌شود که احتمال گران‌تر بودن یک آگهی دارای سند "
            "نسبت به بدون سند حدود <b>۵۶٪</b> است (ضریب رتبه‌ای حدود ۰.۱۱). "
            "یعنی اثر معنادار ولی <b>ملایم</b> است.<br><br>"
            "<b>هشدار مهم:</b> این یک <b>رابطه</b> است نه <b>علیت</b>. "
            "ملک‌های دارای سند ممکن است ذاتاً از نوع گران‌تر (مثلاً دفتر و مغازه‌ی بهتر) باشند.",
            kind="warn",
        )

    # ========================================================
    # TAB 5 — TEST 4
    # ========================================================
    with tabs[4]:
        st.markdown('<div class="subtab-title">آزمون ۴ — امکانات لوکس قیمت را بالا می‌برد؟</div>', unsafe_allow_html=True)

        st.markdown("##### Hypothesis")
        note_box(
            "<b>امکانات لوکس:</b> استخر، جکوزی، سونا، باربیکیو<br><br>"
            "<b>H₀:</b> قیمت گروه لوکس بیشتر نیست.<br>"
            "<b>H₁:</b> قیمت گروه لوکس <b>بیشتر</b> است.<br>"
            "<b>نوع آزمون:</b> Mann-Whitney U یک‌طرفه (one-sided)"
        )

        stat_cards([
            {"value": "5,000",    "label": "Sample Size",     "sub": "random with fixed seed"},
            {"value": "4",        "label": "Luxury Features", "sub": "pool, jacuzzi, sauna, BBQ"},
            {"value": "Filtered", "label": "Data Cleaning",   "sub": "both price and amenities known"},
        ])

        st.markdown("##### Sample Description")
        note_box(
            "یک نمونه‌ی ۵۰۰۰تایی تصادفی (با seed ثابت) از آگهی‌هایی که هم قیمت دارند "
            "و هم وضعیت امکاناتشان مشخص است."
        )

        st.markdown("##### Images — Q-Q, Histogram, and Results")
        show_test_images("azmoon4", width=900)

        note_box(
            "نقاط Q-Q در دُم‌ها از خط نرمال فاصله می‌گیرند. توزیع قیمت پردازش‌شده به نرمال نزدیک است ولی نرمال نیست. "
            "هر دو گروه هیستوگرام شکل زنگوله‌ای تقریباً مشابهی دارند. "
            "هیستوگرام لوکس کمی به سمت قیمت‌های بالاتر رفته است."
        )

        note_box(
            "آزمون شاپیرو برای هر دو گروه p بسیار کوچک می‌دهد، پس مان‌ویتنی انتخاب می‌شود.",
            kind="info",
        )

        st.markdown("##### Decision")
        note_box(
            "<b>p ≈ 3.9 × 10⁻⁵ → فرض صفر رد می‌شود.</b><br>"
            "آگهی‌های دارای امکانات لوکس قیمت بالاتری دارند."
        )

        note_box(
            "نکته‌ی تفسیر: با توجه به اینکه نمونه کوچیک‌تره (۵۰۰۰)، p-value قابل‌اعتمادتر از آزمون‌های "
            "روی یک میلیون رکورده. اندازه‌ی اثر باید در ارائه‌ی نهایی گزارش بشه تا ببینیم چقدر عملی مهمه."
        )

    # ========================================================
    # TAB 6 — SUMMARY
    # ========================================================
    with tabs[5]:
        st.markdown('<div class="subtab-title">جمع‌بندی آزمون‌ها</div>', unsafe_allow_html=True)

        st.markdown("##### All Tests Summary")
        summary_df = pd.DataFrame([
            {"ID": "T1", "Test": "Metro vs Small City", "Method": "Mann-Whitney (1-sided)", "p-value": "3.8e-45", "Effect": "49% (~random)", "Decision": "Reject H₀"},
            {"ID": "T2", "Test": "Old vs New",           "Method": "Mann-Whitney (1-sided)", "p-value": "1.0",     "Effect": "39%",           "Decision": "Fail to reject"},
            {"ID": "T3", "Test": "Business Deed Effect", "Method": "Mann-Whitney (2-sided)", "p-value": "1e-61",   "Effect": "56%",           "Decision": "Reject H₀"},
            {"ID": "T4", "Test": "Luxury Amenities",     "Method": "Mann-Whitney (1-sided)", "p-value": "3.9e-5",  "Effect": "n/a",           "Decision": "Reject H₀"},
        ])
        st.dataframe(summary_df, use_container_width=True, hide_index=True)

        note_box(
            "<b>نتیجه‌ی کلی:</b> از چهار آزمون، سه تا رد شدن و یکی رد نشد. "
            "اما نکته‌ی مهم این است که در دو آزمون (T1 و T3)، اندازه‌ی اثر خیلی کوچک بود "
            "حتی با اینکه p-value بی‌نهایت کوچک بود."
        )

        note_box(
            "<b>درس مهم برای ارائه:</b> در دیتاست‌های بزرگ، p-value تنها معیار تصمیم نیست. "
            "باید اندازه‌ی اثر هم گزارش بشه تا معلوم بشه تفاوت <b>عملاً</b> مهمه یا نه."
        )

        note_box(
            "<b>قوی‌ترین یافته:</b> آزمون T3 (سند تجاری) — هم p-value قوی و هم اندازه‌ی اثر قابل‌توجه.<br>"
            "<b>غافلگیرکننده‌ترین یافته:</b> آزمون T2 — فرضیه‌ی «خانه‌های قدیمی بزرگ‌ترند» در جهت اشتباه بود. "
            "داده نشان داد ملک‌های جدیدتر معمولاً بزرگ‌ترند.<br>"
            "<b>ضعیف‌ترین یافته:</b> آزمون T1 — تفاوت آماری معنادار ولی عملاً ناچیز (شیر یا خط).",
            kind="info",
        )

        note_box(
            "پیشنهاد برای ارائه: هر سه نکته‌ی بالا رو با صداقت کامل بگید. "
            "پنهان کردن اندازه‌ی اثر یا جهت اشتباه آزمون T2، به اعتبار علمی پروژه ضربه می‌زنه.",
            kind="warn",
        )
# ============================================================
# SECTION 2 — BONUS HYPOTHESIS TESTING  (NEW)
# ============================================================
def bonus_hypothesis_tests_page():
    page_header(
        "⭐ Bonus Hypothesis Testing",
        "Three in-depth statistical stories with visual storytelling",
        key="back_bonus_hyp",
    )

    tabs = st.tabs([
        "📌 Overview",
        "🏢 Test 1 — Amenities × Age",
        "🏬 Test 2 — Residential vs Commercial",
        "🔨 Test 3 — Renovation Sale vs Rent",
        "📋 Summary",
    ])

    # ========================================================
    # TAB 1 — OVERVIEW
    # ========================================================
    with tabs[0]:
        st.markdown('<div class="subtab-title">مرور آزمون‌های امتیازی</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "3",       "label": "In-depth Tests", "sub": "with visual storytelling"},
            {"value": "13",      "label": "Charts & Figures", "sub": "step-by-step"},
            {"value": "α = 0.05","label": "Significance", "sub": "standard threshold"},
            {"value": "Tehran",  "label": "Focus Area", "sub": "apartment segment"},
        ])

        st.markdown("##### Three Bonus Hypotheses")
        overview_df = pd.DataFrame([
            {"ID": "B1", "Question": "Do amenity counts differ across building age groups?",   "Method": "Chi-Square",       "Result": "Reject H₀ · V=0.354"},
            {"ID": "B2", "Question": "Is price per m² different between residential and commercial?", "Method": "Kruskal-Wallis", "Result": "Reject H₀ · H=5385.89"},
            {"ID": "B3", "Question": "Is renovation share different between sale and rent?",   "Method": "Fisher's Exact",   "Result": "Reject H₀ · OR=1.11"},
        ])
        st.dataframe(overview_df, use_container_width=True, hide_index=True)

        note_box(
            "هر سه آزمون روی بخشی از دیتاست اجرا شدن که ویژگی‌های خاصی داشتن: "
            "آپارتمان‌های تهران. دلیل: تمرکز جغرافیایی و نوع ملک یکنواخت، تا اثر سایر عوامل کنترل‌شده‌تر باشه. "
            "با این حال، <b>اثر محله و متراژ کنترل نشده</b> و این محدودیت در همه‌ی آزمون‌ها صادقانه مستند شده."
        )

        note_box(
            "<b>نکته مهم برای دفاعیه:</b> در همه‌ی این آزمون‌ها p-value معناداره ولی <b>اندازه‌ی اثر</b> متفاوته. "
            "B1 اثر متوسط داره (V=0.354)، ولی B3 اثر خیلی کوچیک داره (اختلاف فقط ۲.۷۱ واحد درصد). "
            "پنهان کردن این تفاوت، به اعتبار علمی پروژه ضربه می‌زنه.",
            kind="warn",
        )

    # ========================================================
    # TAB 2 — TEST 1: AMENITIES × AGE
    # ========================================================
    with tabs[1]:
        st.markdown('<div class="subtab-title">آزمون ۱ — امکانات × سن ساختمان</div>', unsafe_allow_html=True)

        # ---- Section 1: Question ----
        st.markdown("### ۱. سؤال اصلی")
        note_box(
            "<b>آیا تعداد امکانات آپارتمان‌های تهران در گروه‌های سنی ساختمان متفاوت است؟</b><br><br>"
            "امکانات بررسی‌شده: پارکینگ، آسانسور، انباری، بالکن"
        )

        # ---- Section 2: Data prep ----
        st.markdown("### ۲. آماده‌سازی داده")
        note_box(
            "از <b>۱۴۹,۲۱۶</b> آگهی آپارتمان تهران، پس از حذف اطلاعات نامشخص امکانات و سال ساخت، "
            "<b>۹۷,۵۷۵</b> آگهی باقی ماند.<br><br>"
            "بیشترین حذف مربوط به <b>وضعیت نامشخص بالکن</b> بود."
        )

        # ---- Section 3: Groups & scoring ----
        st.markdown("### ۳. تعریف گروه‌ها و امتیاز")
        note_box(
            "ساختمان‌ها در سه گروه قرار گرفتند:<br>"
            "• <b>۰–۱۰ سال</b><br>"
            "• <b>۱۱–۲۰ سال</b><br>"
            "• <b>۲۱+ سال</b><br><br>"
            "وجود هر امکان <b>یک امتیاز</b> دارد؛ مجموع امتیاز بین <b>صفر تا چهار</b> است."
        )

        # ---- All images for Test 1 ----
        st.markdown("### ۴ تا ۷. نتایج بصری و آماری")
        show_test_images("analysis_1_", width=900)

        # ---- Section 4: Overview ----
        st.markdown("### ۴. تصویر کلی امکانات")
        note_box(
            "در نمونه‌ی نهایی، <b>۵۷.۶۴٪</b> آگهی‌ها هر چهار امکان را دارند. "
            "آیا این سهم در تمام گروه‌های سنی یکسان است؟"
        )

        # ---- Section 5: Main comparison ----
        st.markdown("### ۵. مقایسه‌ی اصلی")
        note_box(
            "سهم داشتن <b>هر چهار امکان</b> در سه گروه سنی به‌ترتیب:<br>"
            "• گروه ۰–۱۰ سال: <b>۷۶.۵۰٪</b><br>"
            "• گروه ۱۱–۲۰ سال: <b>۴۰.۱۹٪</b><br>"
            "• گروه ۲۱+ سال: <b>۱۲.۸۵٪</b><br><br>"
            "برای مقایسه‌ی گروه‌های با اندازه‌ی متفاوت، از <b>درصد داخل هر گروه</b> استفاده شد."
        )

        # ---- Section 6: Statistical test ----
        st.markdown("### ۶. آزمون آماری")
        stat_cards([
            {"value": "24,485.87", "label": "Chi-Square (χ²)"},
            {"value": "8",         "label": "Degrees of Freedom"},
            {"value": "< 0.001",   "label": "p-value", "warn": True},
            {"value": "0.354",     "label": "Cramér's V", "sub": "medium effect"},
        ])

        note_box(
            "فرض صفر: <b>استقلال گروه سنی و امتیاز امکانات</b>.<br>"
            "تمام فراوانی‌های مورد انتظار بالاتر از ۵ بودند (پیش‌نیاز آزمون کای‌دو).<br><br>"
            "<b>نتیجه:</b> χ² = ۲۴,۴۸۵.۸۷، df = ۸، p < ۰.۰۰۱، V = ۰.۳۵۴ → <b>فرض صفر رد شد</b>."
        )

        # ---- Section 7: Interpretation ----
        st.markdown("### ۷. تفسیر و پایان")
        note_box(
            "در گروه <b>جوان‌تر</b>، داشتن چهار امکان بیشتر از انتظار تحت استقلال است.<br>"
            "در گروه <b>مسن‌تر</b>، کمتر از انتظار تحت استقلال است.<br><br>"
            "سن ساختمان و تعداد امکانات <b>ارتباط</b> دارند، اما رابطه‌ی <b>علت‌ومعلولی</b> اثبات نشده است."
        )

        # ---- Highlight ----
        stat_cards([
            {"value": "63.65", "label": "Percentage point difference", "sub": "between group 0–10 and 21+", "warn": True},
        ])

        note_box(
            "<b>«اختلاف سهم داشتن هر چهار امکان بین گروه ۰–۱۰ و ۲۱+ سال، ۶۳.۶۵ واحد درصد است.»</b>",
            kind="info",
        )

        # ---- Limitations ----
        st.markdown("### محدودیت‌ها")
        note_box(
            "• اطلاعات ناقص حذف شده (حدود ۳۵٪ آگهی‌ها)<br>"
            "• سن ساختمان تقریبی است<br>"
            "• فروش و اجاره تجمیع شده‌اند<br>"
            "• اثر محله و متراژ کنترل نشده است",
            kind="warn",
        )

    # ========================================================
    # TAB 3 — TEST 2: RESIDENTIAL VS COMMERCIAL
    # ========================================================
    with tabs[2]:
        st.markdown('<div class="subtab-title">آزمون ۲ — قیمت هر متر: مسکونی vs تجاری</div>', unsafe_allow_html=True)

        # ---- Section 1: Question ----
        st.markdown("### ۱. سؤال اصلی")
        note_box(
            "<b>آیا توزیع قیمت هر متر مربع بین آپارتمان‌های مسکونی و دفترها و مغازه‌های تهران متفاوت است؟</b>"
        )

        # ---- Section 2: Sample ----
        st.markdown("### ۲. معرفی نمونه")
        stat_cards([
            {"value": "84,586", "label": "Residential Ads", "sub": "initial sample"},
            {"value": "5,409",  "label": "Commercial Ads",  "sub": "initial sample"},
        ])

        note_box(
            "ابتدا <b>۸۴,۵۸۶ آگهی مسکونی</b> و <b>۵,۴۰۹ آگهی تجاری</b> انتخاب شد. "
            "تحلیل فقط مربوط به <b>آگهی‌های فروش تهران</b> است."
        )

        # ---- All images for Test 2 ----
        st.markdown("### ۳ تا ۷. نتایج بصری و آماری")
        show_test_images("analysis_2_", width=900)

        # ---- Section 3: Cleaning ----
        st.markdown("### ۳. پاک‌سازی داده")
        note_box(
            "• <b>۹۹۶ آگهی</b> با قیمت یا متراژ نامعتبر حذف شدند.<br>"
            "• سپس <b>۲,۹۳۲ آگهی</b> با مقادیر پرتِ قیمت کل یا متراژ حذف شدند."
        )

        # ---- Section 4: Final sample ----
        st.markdown("### ۴. نمونه‌ی نهایی")
        stat_cards([
            {"value": "86,067", "label": "Final Total",   "sub": "ads retained"},
            {"value": "82,191", "label": "Residential",   "sub": "97.17% retention"},
            {"value": "3,876",  "label": "Commercial",    "sub": "71.66% retention"},
        ])

        note_box(
            "در نهایت <b>۸۶,۰۶۷ آگهی</b> باقی ماند: ۸۲,۱۹۱ مسکونی و ۳,۸۷۶ تجاری.<br>"
            "میزان حفظ داده در مسکونی <b>۹۷.۱۷٪</b> و در تجاری <b>۷۱.۶۶٪</b> بود."
        )

        # ---- Section 5: Shape of distributions ----
        st.markdown("### ۵. شکل توزیع‌ها")
        note_box(
            "هر دو بازار دنباله‌ای به سمت قیمت‌های بالا دارند. "
            "نمودار <b>درصدی با بازه‌های مشترک</b>، مقایسه‌ی دو گروه را با وجود تفاوت تعداد آگهی‌ها آسان‌تر می‌کند."
        )

        # ---- Section 6: Price comparison ----
        st.markdown("### ۶. مقایسه‌ی قیمت‌ها")
        stat_cards([
            {"value": "85 M",  "label": "Residential Median", "sub": "per m²"},
            {"value": "200 M", "label": "Commercial Median",   "sub": "per m²", "warn": True},
            {"value": "2.35×", "label": "Ratio",                "sub": "commercial / residential"},
        ])

        note_box(
            "میانه‌ی قیمت هر متر مربع در مسکونی <b>۸۵ میلیون</b> و در تجاری <b>۲۰۰ میلیون</b> است؛ "
            "میانه‌ی تجاری حدود <b>۲.۳۵ برابر</b> مسکونی است."
        )

        # ---- Section 7: CDF ----
        st.markdown("### ۷. توضیح توزیع تجمعی")
        note_box(
            "در هر قیمت، ارتفاع منحنی نشان می‌دهد چند درصد آگهی‌ها قیمتی کمتر یا مساوی آن دارند. "
            "خط <b>۵۰٪</b> برای خواندن <b>میانه</b> است."
        )

        # ---- Section 8: Statistical test ----
        st.markdown("### ۸. آزمون فرض")
        stat_cards([
            {"value": "5,385.89", "label": "Kruskal-Wallis H"},
            {"value": "< 0.001",  "label": "p-value", "warn": True},
        ])

        note_box(
            "فرض صفر: <b>یکسان بودن توزیع قیمت‌ها</b>.<br>"
            "آزمون کروسکال-والیس با <b>H = ۵,۳۸۵.۸۹</b> و <b>p < ۰.۰۰۱</b> فرض صفر را رد می‌کند؛ "
            "شواهدی از تفاوت در رتبه‌های قیمت وجود دارد."
        )

        # ---- Final message ----
        note_box(
            "<b>پیام پایانی:</b> در نمونه‌ی بررسی‌شده، میانه‌ی قیمت پیشنهادی هر متر مربع تجاری بالاتر است "
            "و آزمون نیز تفاوت آماری را نشان می‌دهد. "
            "اثر محله، متراژ و سایر ویژگی‌ها کنترل نشده؛ بنابراین نتیجه <b>علت‌ومعلولی نیست</b>.",
            kind="info",
        )

        note_box(
            "<b>واحد قیمت:</b> «میلیون واحد پول دیتاست به‌ازای متر مربع». "
            "تومان یا ریال در فایل تأیید نشده است.",
            kind="warn",
        )

    # ========================================================
    # TAB 4 — TEST 3: RENOVATION SALE VS RENT
    # ========================================================
    with tabs[3]:
        st.markdown('<div class="subtab-title">آزمون ۳ — بازسازی در فروش و اجاره</div>', unsafe_allow_html=True)

        # ---- Section 1: Question ----
        st.markdown("### ۱. سؤال اصلی")
        note_box(
            "<b>آیا سهم آپارتمان‌های بازسازی‌شده در آگهی‌های فروش و اجاره‌ی تهران متفاوت است؟</b>"
        )

        # ---- Section 2: Sample ----
        st.markdown("### ۲. معرفی نمونه")
        stat_cards([
            {"value": "84,586", "label": "Sale Ads",  "sub": "initial sample"},
            {"value": "64,630", "label": "Rent Ads",  "sub": "initial sample"},
            {"value": "149,216","label": "Total",      "sub": "Tehran apartments"},
        ])

        note_box(
            "ابتدا <b>۸۴,۵۸۶ آگهی فروش</b> و <b>۶۴,۶۳۰ آگهی اجاره</b> انتخاب شد؛ "
            "در مجموع <b>۱۴۹,۲۱۶ آگهی آپارتمان تهران</b>."
        )

        # ---- Section 3: Unknown status ----
        st.markdown("### ۳. اطلاعات نامشخص")
        note_box(
            "وضعیت بازسازی در <b>۴۱,۶۱۷ آگهی</b> نامشخص بود و این آگهی‌ها کنار گذاشته شدند.<br><br>"
            "<b>نکته مهم:</b> اطلاعات نامشخص به معنی بازسازی‌نشده <b>نیست</b>."
        )

        # ---- Section 4: Final sample ----
        st.markdown("### ۴. نمونه‌ی نهایی")
        stat_cards([
            {"value": "61,904", "label": "Sale Records",  "sub": "after cleaning"},
            {"value": "45,695", "label": "Rent Records",  "sub": "after cleaning"},
        ])

        note_box(
            "تحلیل روی <b>۶۱,۹۰۴ آگهی فروش</b> و <b>۴۵,۶۹۵ آگهی اجاره</b> انجام شد. "
            "چون اندازه‌ی گروه‌ها متفاوت است، <b>نسبت‌ها</b> را مقایسه می‌کنیم."
        )

        # ---- Images ----
        st.markdown("### ۵. مقایسه‌ی اصلی")
        show_test_images("analysis_3_", width=900)

        stat_cards([
            {"value": "51.86%", "label": "Renovation Share — Sale", "warn": False},
            {"value": "49.15%", "label": "Renovation Share — Rent", "warn": False},
            {"value": "2.71",   "label": "Difference (pp)",          "warn": True},
        ])

        note_box(
            "سهم بازسازی‌شده‌ها در <b>فروش ۵۱.۸۶٪</b> و در <b>اجاره ۴۹.۱۵٪</b> است؛ "
            "اختلاف برابر <b>۲.۷۱ واحد درصد</b> است."
        )

        # ---- Contingency table ----
        st.markdown("##### Contingency Table")
        ct_df = pd.DataFrame([
            {"Market": "Sale",  "Renovated": 32106, "Not Renovated": 29798, "Total": 61904},
            {"Market": "Rent",  "Renovated": 22459, "Not Renovated": 23236, "Total": 45695},
        ])
        st.dataframe(ct_df, use_container_width=True, hide_index=True)

        # ---- Statistical test ----
        st.markdown("### ۶. آزمون فرض")
        stat_cards([
            {"value": "Fisher", "label": "Test Type", "sub": "two-sided"},
            {"value": "1.34e-18", "label": "p-value", "warn": True},
            {"value": "1.1147", "label": "Odds Ratio"},
        ])

        note_box(
            "فرض صفر: <b>برابری نسبت بازسازی در دو بازار</b>.<br>"
            "آزمون دقیق فیشرِ دوطرفه با <b>p ≈ ۱.۳۴ × ۱۰⁻¹⁸</b> فرض صفر را در سطح ۰.۰۵ رد می‌کند."
        )

        # ---- Effect size ----
        st.markdown("### ۷. اندازه‌ی تفاوت و تفسیر")
        note_box(
            "شواهد آماری از تفاوت نسبت‌ها وجود دارد، اما اختلاف مشاهده‌شده حدود <b>۲.۷ واحد درصد</b> است. "
            "<b>کوچک بودن مقدار p به‌تنهایی نشان‌دهنده‌ی بزرگ بودن تفاوت نیست.</b>"
        )

        note_box(
            "<b>نسبت شانس ۱.۱۱۴۷</b> یعنی شانس بازسازی در فروش حدود <b>۱۱.۴۷٪</b> بالاتر است. "
            "این عدد با افزایش احتمال یا اختلاف درصدی <b>یکی نیست</b>.",
            kind="info",
        )

        # ---- Highlight ----
        note_box(
            "<b>«در آگهی‌های دارای وضعیت مشخص، سهم بازسازی‌شده‌ها در فروش ۲.۷۱ واحد درصد بیشتر است.»</b>",
            kind="info",
        )

        # ---- Final message ----
        st.markdown("### متن پایان")
        note_box(
            "در آگهی‌های آپارتمان تهران با وضعیت بازسازی مشخص، سهم بازسازی‌شده‌ها در فروش کمی بالاتر از اجاره بود "
            "و این تفاوت از نظر آماری معنی‌دار شد.<br><br>"
            "نتیجه به نمونه‌ی دارای اطلاعات مشخص مربوط است؛ "
            "سن ساختمان، محله و متراژ کنترل نشده‌اند و رابطه‌ی <b>علت‌ومعلولی</b> اثبات نمی‌شود."
        )

        # ---- Method note ----
        st.markdown("### توضیح روش")
        note_box(
            "آزمون فیشر به نرمال‌بودن یا برابر بودن تعداد گروه‌ها نیاز ندارد؛ "
            "استقلال مشاهدات در این تحلیل فرض شده است."
        )

    # ========================================================
    # TAB 5 — SUMMARY
    # ========================================================
    with tabs[4]:
        st.markdown('<div class="subtab-title">جمع‌بندی آزمون‌های امتیازی</div>', unsafe_allow_html=True)

        st.markdown("##### All Bonus Tests Summary")
        summary_df = pd.DataFrame([
            {"ID": "B1", "Test": "Amenities × Age Groups",     "Method": "Chi-Square",     "Statistic": "χ²=24485.87", "p-value": "< 0.001", "Effect": "V=0.354 (medium)",  "Decision": "Reject H₀"},
            {"ID": "B2", "Test": "Residential vs Commercial",  "Method": "Kruskal-Wallis", "Statistic": "H=5385.89",   "p-value": "< 0.001", "Effect": "Median ratio 2.35×", "Decision": "Reject H₀"},
            {"ID": "B3", "Test": "Renovation Sale vs Rent",    "Method": "Fisher's Exact", "Statistic": "OR=1.1147",   "p-value": "1.34e-18","Effect": "2.71 pp diff",       "Decision": "Reject H₀"},
        ])
        st.dataframe(summary_df, use_container_width=True, hide_index=True)

        note_box(
            "<b>نتیجه‌ی کلی:</b> هر سه آزمون از نظر آماری معنادار بودن. اما <b>اندازه‌ی اثرها</b> متفاوته:"
        )

        note_box(
            "<b>قوی‌ترین یافته (B2):</b> میانه‌ی قیمت هر متر مربع تجاری <b>۲.۳۵ برابر</b> مسکونی است. "
            "این تفاوت هم آماری و هم عملی معنادار است.<br><br>"
            "<b>متوسط (B1):</b> امکانات با سن ساختمان ارتباط دارند (V=0.354). "
            "اختلاف ۶۳.۶۵ واحد درصدی بین جوان‌ترین و قدیمی‌ترین گروه‌ها چشمگیره.<br><br>"
            "<b>ضعیف‌ترین (B3):</b> تفاوت آماری معنادار ولی عملاً <b>ناچیز</b> (۲.۷۱ واحد درصد). "
            "این یک یادآوری مهمه که p-value کوچک به‌تنهایی بزرگ‌بودن اثر رو نشون نمی‌ده.",
            kind="info",
        )

        note_box(
            "<b>محدودیت‌های مشترک هر سه آزمون:</b><br>"
            "• <b>B1:</b> اطلاعات ناقص حذف شده (۳۵٪)، سن تقریبی، فروش و اجاره تجمیع، اثر محله و متراژ کنترل نشده.<br>"
            "• <b>B2:</b> اثر محله، متراژ و سایر ویژگی‌ها کنترل نشده؛ نتیجه علت‌ومعلولی نیست.<br>"
            "• <b>B3:</b> نتیجه به نمونه‌ی دارای اطلاعات مشخص مربوط است؛ سن، محله و متراژ کنترل نشده.",
            kind="warn",
        )

        note_box(
            "<b>پیام نهایی برای ارائه:</b> هر سه آزمون <b>رابطه</b> رو نشون می‌دن، نه <b>علیت</b>. "
            "این تفکیک برای اعتبار علمی پروژه حیاتیه. "
            "همچنین در همه‌ی موارد، <b>اندازه‌ی اثر</b> رو در کنار p-value گزارش کنید."
        )


# ============================================================
# SECTION 3 — CLUSTERING
# ============================================================
def clustering_page():
    page_header(
        "🎯 Clustering / Recommender",
        "K-Means, k-selection, and DBSCAN on Divar real estate data",
        key="back_cluster",
    )

    tabs = st.tabs([
        "📌 Overview",
        "🧹 Data Prep",
        "🎯 Feature Selection",
        "🔵 Part 1 — K-Means k=10",
        "📐 Part 2 — Choosing k",
        "🔶 Part 3 — DBSCAN",
        "📋 Limitations",
        "📎 Appendix",
    ])

    # ========================================================
    # TAB 1 — OVERVIEW
    # ========================================================
    with tabs[0]:
        st.markdown('<div class="subtab-title">مرور کلی پروژه</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "1,000,000", "label": "Total Ads",             "sub": "Divar dataset"},
            {"value": "3",         "label": "Independent Groups",     "sub": "sale / rent / daily"},
            {"value": "4",         "label": "Selected Features",      "sub": "for clustering"},
            {"value": "3",         "label": "Exercise Sub-questions", "sub": "Part 1, 2, 3"},
        ])

        st.markdown("##### N1 — Dataset Split")
        pie_df = pd.DataFrame({
            "Group": ["Sale", "Rent", "Daily Rent", "Real Estate Services"],
            "Count": [597569, 353125, 29903, 19403],
        })
        fig = px.pie(
            pie_df, names="Group", values="Count",
            color_discrete_sequence=["#1e3a8a", "#2563eb", "#60a5fa", "#cbd5e1"],
            hole=0.35,
        )
        fig.update_traces(textposition="outside", textinfo="percent+label")
        fig.update_layout(font=dict(size=13), margin=dict(l=20, r=20, t=20, b=20), height=440)
        st.plotly_chart(fig, use_container_width=True)

        note_box(
            "سه گروه اول به‌صورت مستقل خوشه‌بندی می‌شوند چون واحد اقتصادی‌شان متفاوت است: "
            "میلیارد تومان برای فروش، میلیون ماهانه برای رهن، صد هزار شبانه برای روزانه. "
            "خدمات ملکی کنار گذاشته شد چون آگهی مشاور و پیمانکار اصلاً ملک نیست."
        )

        st.markdown("##### Project Architecture")
        arch_df = pd.DataFrame([
            {"Path": "A — Preparation",   "Description": "Prerequisite for all paths"},
            {"Path": "B — Main Question", "Description": "Official answer (Parts 1, 2, 3)"},
            {"Path": "C — Supplementary", "Description": "K-Means in extended feature space"},
            {"Path": "D — Alternative",   "Description": "DBSCAN with shared UTM and ECEF"},
        ])
        st.dataframe(arch_df, use_container_width=True, hide_index=True)

    # ========================================================
    # TAB 2 — DATA PREPARATION
    # ========================================================
    with tabs[1]:
        st.markdown('<div class="subtab-title">آماده‌سازی داده</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "724",   "label": "Recovered \"30+\" values"},
            {"value": "1,252", "label": "Floor mismatches", "sub": "740 sale + 512 rent"},
            {"value": "676",   "label": "Zero daily rates",  "sub": "across 328 ads"},
            {"value": "1",     "label": "Only numeric fix",  "sub": "zero → missing"},
        ])

        st.markdown("##### Cell-Level Fixes (Cell 30)")
        fix_df = pd.DataFrame([
            {"Column": "rent_price_on_regular_days", "Cells Changed": 207, "Missing Before": 11835, "Missing After": 12042},
            {"Column": "rent_price_on_special_days", "Cells Changed": 241, "Missing Before": 19440, "Missing After": 19681},
            {"Column": "rent_price_at_weekends",     "Cells Changed": 228, "Missing Before": 16352, "Missing After": 16580},
        ])
        st.dataframe(fix_df, use_container_width=True, hide_index=True)

        st.markdown("##### Filtering Pipeline")
        pipe_df = pd.DataFrame([
            {"Group": "Sale",  "Raw": 597569, "Feature Eligible": 545200, "Spatial Eligible": 362647},
            {"Group": "Rent",  "Raw": 353125, "Feature Eligible": 338688, "Spatial Eligible": 230439},
            {"Group": "Daily", "Raw": 29903,  "Feature Eligible": 17180,  "Spatial Eligible": 12046},
        ])
        st.dataframe(pipe_df, use_container_width=True, hide_index=True)

        fig = go.Figure()
        for col, color in [("Raw", "#cbd5e1"), ("Feature Eligible", "#60a5fa"), ("Spatial Eligible", "#1e3a8a")]:
            fig.add_trace(go.Bar(
                name=col, x=pipe_df["Group"], y=pipe_df[col],
                marker_color=color,
                text=[f"{v:,}" for v in pipe_df[col]],
                textposition="outside",
            ))
        fig.update_layout(
            barmode="group",
            title="Raw → Feature-Ready → Spatial-Ready",
            yaxis_title="Number of Ads",
            font=dict(size=12),
            title_font=dict(size=16, color="#1e3a8a"),
            margin=dict(l=20, r=20, t=60, b=20),
            height=440,
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        )
        st.plotly_chart(fig, use_container_width=True)

        st.markdown("##### Model Exclusion Reasons")
        excl_df = pd.DataFrame([
            {"Reason": "Price missing",           "Sale": "—",      "Rent": "—",     "Daily": "—"},
            {"Reason": "Non-positive area",       "Sale": "—",      "Rent": "—",     "Daily": "—"},
            {"Reason": "Missing coordinates",     "Sale": "—",      "Rent": "—",     "Daily": "—"},
            {"Reason": "Out of percentile range", "Sale": "11,619", "Rent": "7,203", "Daily": "358"},
        ])
        st.dataframe(excl_df, use_container_width=True, hide_index=True)

        note_box(
            "پاک‌سازی در دو لایه انجام شد. لایهٔ ساختاری: ارقام فارسی به لاتین، بولی‌ها به nullable، "
            "و مقادیر «۳۰+» به حد پایین با فلگ جداگانه. لایهٔ اعتبارسنجی: بیست چک، هیچ‌کدام خودکار اصلاح نکرد. "
            "تنها یک اصلاح عددی: صفر روزانه به missing، چون نرخ صفر یعنی رایگان که در آگهی اجاره بی‌معناست."
        )

        note_box(
            "تنها یک اصلاح عددی در کل پروژه اعمال شد. ۷۴۰ اختلاف طبقه و ۱۷ سال ساخت آینده "
            "فقط فلگ گرفتند، بدون تغییر مقدار. این تصمیم برای حفظ قابلیت حسابرسی است.",
            kind="warn",
        )

    # ========================================================
    # TAB 3 — FEATURE SELECTION
    # ========================================================
    with tabs[2]:
        st.markdown('<div class="subtab-title">انتخاب ویژگی</div>', unsafe_allow_html=True)

        st.markdown("##### Five Selection Criteria")
        crit_df = pd.DataFrame([
            {"Criterion": "User preference relevance",      "Description": "Matches what users choose by"},
            {"Criterion": "Discriminative",                 "Description": "Has diverse values across rows"},
            {"Criterion": "Low correlation",                "Description": "Doesn't add redundant info"},
            {"Criterion": "Avoids curse of dimensionality", "Description": "Keeps feature count under 10"},
            {"Criterion": "Numerical stability",            "Description": "Reasonable scale for distance metrics"},
        ])
        st.dataframe(crit_df, use_container_width=True, hide_index=True)

        st.markdown("##### Feature Decision Table")
        feat_df = pd.DataFrame([
            {"Feature": "Price (per group)",            "Decision": "✅", "Reason": "Main user criterion"},
            {"Feature": "building_size",                "Decision": "✅", "Reason": "Size criterion"},
            {"Feature": "cat3_slug (One-Hot)",          "Decision": "✅", "Reason": "Apartment / Villa / Shop"},
            {"Feature": "UTM_X, UTM_Y",                 "Decision": "✅", "Reason": "Geographic location"},
            {"Feature": "rooms_count",                  "Decision": "❌", "Reason": "Weak correlation with area"},
            {"Feature": "floor",                        "Decision": "❌", "Reason": "Meaningful only for apartments"},
            {"Feature": "construction_year",            "Decision": "❌", "Reason": "High NaN + recording errors"},
            {"Feature": "Boolean flags (parking etc.)", "Decision": "❌", "Reason": "Low variance"},
        ])
        st.dataframe(feat_df, use_container_width=True, hide_index=True)

        st.markdown("##### N2 — Correlation Heatmap")
        show_image("correlation_heatmap.png", "7×7 correlation matrix on 10k sale sample", width=750)

        note_box(
            "ماتریس همبستگی هیچ جفت ویژگی با |r| بالای ۰.۵ نشان نمی‌دهد. "
            "بیشترین مقدار: latitude ↔ longitude = -0.24. "
            "نکتهٔ مهم: حذف rooms_count و floor به‌خاطر همبستگی نبود، "
            "برای سادگی و اجتناب از نفرین ابعاد بود."
        )

    # ========================================================
    # TAB 4 — PART 1
    # ========================================================
    with tabs[3]:
        st.markdown('<div class="subtab-title">Part 1 — K-Means با k=10</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "200,921", "label": "Sale — WCSS",  "sub": "362,647 rows"},
            {"value": "124,420", "label": "Rent — WCSS",  "sub": "230,439 rows"},
            {"value": "4,279",   "label": "Daily — WCSS", "sub": "12,046 rows"},
        ])

        note_box(
            "<b>ماتریس ورودی فقط سه ستون دارد: utm_x, utm_y, log_price.</b> "
            "هیچ ویژگی دیگری — نه مساحت، نه نوع ملک، نه امکانات — وارد نشد. "
            "این رعایت دقیق صورت تمرین است.",
            kind="info",
        )

        st.markdown("##### N3 — K-Means Scatter: Sale")
        show_image("kmeans_scatter_sales.png", "Left: UTM_x vs UTM_y  |  Right: UTM_x vs log(price)", width=1100)

        st.markdown("##### N4 — K-Means Scatter: Rent")
        show_image("kmeans_scatter_rent.png", "Left: UTM_x vs UTM_y  |  Right: UTM_x vs log(price)", width=1100)

        st.markdown("##### N5 — K-Means Scatter: Daily")
        show_image("kmeans_scatter_daily.png", "Note: C7 outlier visible in top-left corner", width=1100)

        st.markdown("##### Three-Step Transformation")
        step_df = pd.DataFrame([
            {"Step": 1, "Action": "Convert coordinates to UTM Zone 39N", "Reason": "Central Iran lies in this zone"},
            {"Step": 2, "Action": "Log-transform price with log1p",      "Reason": "Compress wide numerical range"},
            {"Step": 3, "Action": "StandardScaler on all three columns", "Reason": "Prevent UTM from dominating log_price"},
        ])
        st.dataframe(step_df, use_container_width=True, hide_index=True)

        note_box(
            "در پنل راست، خوشه‌ها به‌صورت نوارهای افقی در سطوح قیمتی مختلف دیده می‌شوند. "
            "یعنی قیمت واقعاً در خوشه‌بندی نقش داشته، نه فقط موقعیت جغرافیایی. "
            "اگر قیمت بی‌اثر بود، همهٔ خوشه‌ها روی یک نوار افقی می‌افتادند. "
            "در پنل چپ، خوشه‌ها به‌صورت بلوک‌های جغرافیایی مجزا دیده می‌شوند."
        )

    # ========================================================
    # TAB 5 — PART 2
    # ========================================================
    with tabs[4]:
        st.markdown('<div class="subtab-title">Part 2 — انتخاب مقدار k</div>', unsafe_allow_html=True)

        st.markdown("##### Best k per Metric")
        k_df = pd.DataFrame([
            {"Metric": "Elbow (WCSS)",      "Sale": 4, "Rent": 4, "Daily": 4},
            {"Metric": "Silhouette",        "Sale": 4, "Rent": 3, "Daily": 4},
            {"Metric": "Davies-Bouldin",    "Sale": 4, "Rent": 4, "Daily": 4},
            {"Metric": "Calinski-Harabasz", "Sale": 7, "Rent": 4, "Daily": 9},
        ])
        st.dataframe(k_df, use_container_width=True, hide_index=True)

        st.markdown("##### N6 — Four Metrics vs k")
        show_image("four_metrics.png", "WCSS · Silhouette · Calinski-Harabasz · Davies-Bouldin", width=1100)

        note_box(
            "Silhouette اوج خود را در k=4 دارد (sales=0.49، rent=0.38، daily=0.55). "
            "Davies-Bouldin کمینهٔ دقیق خود را در k=4. WCSS شیبش در k=4 تغییر می‌کند. "
            "این توافق سه از چهار معیار، شاهد قوی است که ساختار درشت داده چهار قطعه است: "
            "ارزان، متوسط، گران، لاکچری."
        )

        st.markdown("##### k=4 vs k=10")
        cmp_df = pd.DataFrame([
            {"k=4": "Natural data structure", "k=10": "Finer decomposition"},
            {"k=4": "Confirmed by 3 metrics", "k=10": "Required by exercise"},
            {"k=4": "Coarse market segments", "k=10": "Fine-grained taste groups"},
        ])
        st.dataframe(cmp_df, use_container_width=True, hide_index=True)

        note_box(
            "این تناقض نیست. k=4 نشان می‌دهد داده ذاتاً چهار گروه دارد. "
            "k=10 همان گروه‌ها را ریزتر می‌کند. برای سیستم توصیه‌گر، گروه‌های ریزتر "
            "توصیهٔ دقیق‌تر می‌سازند. ما هر دو را گزارش می‌کنیم."
        )

    # ========================================================
    # TAB 6 — PART 3
    # ========================================================
    with tabs[5]:
        st.markdown('<div class="subtab-title">Part 3 — DBSCAN با ۳ خوشه</div>', unsafe_allow_html=True)

        st.markdown("##### Final Hyperparameters")
        db_df = pd.DataFrame([
            {"Group": "Sale",  "eps": 0.45, "min_samples": 250, "Data Size": "40,000 (sample of 362,647)", "Noise": "10.0%", "Distribution": "79.2% + 6.7% + 4.1%"},
            {"Group": "Rent",  "eps": 0.50, "min_samples": 300, "Data Size": "40,000 (sample of 230,439)", "Noise": "8.7%",  "Distribution": "81.8% + 8.4% + 1.1%"},
            {"Group": "Daily", "eps": 0.60, "min_samples": 300, "Data Size": "12,046 (full)",              "Noise": "13.8%", "Distribution": "74.0% + 8.7% + 3.4%"},
        ])
        st.dataframe(db_df, use_container_width=True, hide_index=True)

        note_box(
            "پارامترها از یک جستجوی شبکه‌ای دقیق آمد. سه شرط: دقیقاً ۳ خوشه، نویز زیر ۳۰٪، "
            "کوچک‌ترین خوشه حداقل ۵٪. اگر فقط ۳ خوشه شرط بود، با نویز ۹۸٪ هم قابل دسترسی بود که بی‌معناست."
        )

        note_box(
            "فروش و رهن روی نمونهٔ ۴۰ هزارتایی اجرا شدند چون اجرای کامل از حافظهٔ "
            "موجود فراتر می‌رفت. روزانه روی کل ۱۲,۰۴۶ ردیف اجرا شد.",
            kind="warn",
        )

        st.markdown("##### N7 — DBSCAN Scatter: Sale")
        show_image("dbscan_sales.png", "Three clusters + grey noise", width=1100)

        st.markdown("##### N8 — DBSCAN Scatter: Rent")
        show_image("dbscan_rent.png", "Three clusters + grey noise", width=1100)

        st.markdown("##### N9 — DBSCAN Scatter: Daily")
        show_image("dbscan_daily.png", "Three clusters + grey noise", width=1100)

        note_box(
            "خوشه‌ها در فضای مکانی، بلوک‌های کاملاً مجزا هستند. در فضای قیمتی، همپوشانی بیشتری دارند "
            "ولی همچنان قابل تفکیک. این نشان می‌دهد جدایی مکانی قوی‌تر از جدایی قیمتی است."
        )

        st.markdown("##### Cluster Interpretation")
        interp_df = pd.DataFrame([
            {"Cluster": "C0", "Share": "~80%",  "Region": "Central Iran", "Cities": "Tehran, Karaj, Isfahan"},
            {"Cluster": "C1", "Share": "~7-8%", "Region": "East",         "Cities": "Mashhad"},
            {"Cluster": "C2", "Share": "~1-4%", "Region": "South",        "Cities": "Shiraz, Kerman"},
        ])
        st.dataframe(interp_df, use_container_width=True, hide_index=True)

        note_box(
            "این سه منطقه دقیقاً سه قطب اقتصادی بازار مسکن ایران هستند. چرا خوشه‌ها جغرافیایی شدند نه قیمتی؟ "
            "داده‌های مکانی گسسته‌اند — بین شهرها فاصلهٔ خالی بزرگ. داده‌های قیمتی پیوسته‌اند. "
            "DBSCAN که بر اساس چگالی کار می‌کند، گسستگی مکانی را اول می‌بیند. این یافته است، ضعف نیست."
        )

        st.markdown("##### Cluster Profiles")
        prof_df = pd.DataFrame([
            {"Cluster": "C0",    "Count": 31686, "Share": "79.2%", "Median Price": "3 B",   "Top Cities": "Tehran, Karaj", "Type": "apartment"},
            {"Cluster": "C1",    "Count": 2697,  "Share": "6.7%",  "Median Price": "2.6 B", "Top Cities": "Mashhad",       "Type": "apartment"},
            {"Cluster": "C2",    "Count": 1628,  "Share": "4.1%",  "Median Price": "3.55 B","Top Cities": "Shiraz",        "Type": "apartment"},
            {"Cluster": "Noise", "Count": 3989,  "Share": "10.0%", "Median Price": "—",     "Top Cities": "—",             "Type": "—"},
        ])
        st.dataframe(prof_df, use_container_width=True, hide_index=True)

        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown("##### Effect of eps")
            eps_df = pd.DataFrame([
                {"eps": "Small (0.3-0.4)",   "Effect": "Small scattered clusters, high noise"},
                {"eps": "Medium (0.45-0.6)", "Effect": "Meaningful, balanced clusters"},
                {"eps": "Large (1.0+)",      "Effect": "Clusters merge, count drops"},
            ])
            st.dataframe(eps_df, use_container_width=True, hide_index=True)
        with col_b:
            st.markdown("##### Effect of min_samples")
            ms_df = pd.DataFrame([
                {"min_samples": "Small (5-50)",    "Effect": "Everything is core, meaningless clusters"},
                {"min_samples": "Medium (250-300)","Effect": "Balance between noise and meaning"},
                {"min_samples": "Large (500+)",    "Effect": "Almost all noise, few clusters"},
            ])
            st.dataframe(ms_df, use_container_width=True, hide_index=True)

        st.markdown("##### 3-Step Search Strategy")
        ss_df = pd.DataFrame([
            {"Step": 1, "Condition": "≥5%, noise ≤30%",             "Result": "0 combinations"},
            {"Step": 2, "Condition": "≥2%, noise ≤50%",             "Result": "Few combinations"},
            {"Step": 3, "Condition": "Lowest noise + best balance", "Result": "Final parameters"},
        ])
        st.dataframe(ss_df, use_container_width=True, hide_index=True)

        note_box(
            "صورت تمرین دقیقاً پاسخ سؤال آخر را خواسته: نحوهٔ اثرگذاری hyperparameterها. "
            "این سه گام نشان می‌دهد که چطور پارامتر مناسب پیدا شد، نه اینکه از کجا آمده."
        )

    # ========================================================
    # TAB 7 — LIMITATIONS
    # ========================================================
    with tabs[6]:
        st.markdown('<div class="subtab-title">محدودیت‌ها و جمع‌بندی</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "55.2%",   "label": "Daily DBSCAN noise", "warn": True},
            {"value": "18.13 GB","label": "Memory needed (sale)","warn": True},
            {"value": "3.03 GB", "label": "Available RAM",       "warn": True},
        ])

        st.markdown("##### DBSCAN Memory Estimation (Cell 112)")
        mem_df = pd.DataFrame([
            {"Group": "Sale",  "eps": 25, "Suggested min_samples": 11605, "Neighbor Entries (M)": 5499.9, "Memory (GB)": 88.00},
            {"Group": "Rent",  "eps": 10, "Suggested min_samples": 3457,  "Neighbor Entries (M)": 565.5,  "Memory (GB)": 9.05},
            {"Group": "Daily", "eps": 25, "Suggested min_samples": 386,   "Neighbor Entries (M)": 3.7,    "Memory (GB)": 0.06},
        ])
        st.dataframe(mem_df, use_container_width=True, hide_index=True)

        st.markdown("##### N15 — Memory Requirements")
        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=["Sale", "Rent", "Daily"],
            y=[88.0, 9.05, 0.06],
            marker_color=["#dc2626", "#f59e0b", "#10b981"],
            text=["88 GB", "9.05 GB", "0.06 GB"],
            textposition="outside",
        ))
        fig.add_hline(
            y=3.03, line_dash="dash", line_color="#dc2626",
            annotation_text="Available RAM (3.03 GB)",
            annotation_position="top right",
        )
        fig.update_layout(
            yaxis_title="Memory (GB)",
            font=dict(size=12),
            title_font=dict(size=16, color="#1e3a8a"),
            margin=dict(l=20, r=20, t=40, b=20),
            height=400,
        )
        st.plotly_chart(fig, use_container_width=True)

        note_box(
            "برای فروش در eps=10، تخمین BallTree نشان داد حدود ۱.۱۳ میلیارد همسایه لازم است "
            "که حدود ۱۸ گیگابایت حافظه می‌طلبد. RAM موجود فقط ۳ گیگابایت بود. "
            "این محدودیت سخت‌افزاری واقعی است، نه انتخاب ما. "
            "فقط روزانه در محدودهٔ اجرا بود که کامل اجرا شد.",
            kind="warn",
        )

        st.markdown("##### Geographic DBSCAN — Daily Rentals")
        st.caption("Using raw longitude/latitude instead of UTM, 5 clusters found")

        st.markdown("##### N14 — DBSCAN Geographic (Daily)")
        show_image("dbscan_daily_geographic.png", "5 clusters + noise (grey)", width=1100)

        alt_df = pd.DataFrame([
            {"Cluster": "C0",    "Region": "Tehran & suburbs",        "Color": "Blue"},
            {"Cluster": "C1",    "Region": "Northern coast (Ramsar)", "Color": "Orange"},
            {"Cluster": "C2",    "Region": "Mashhad",                 "Color": "Dark orange"},
            {"Cluster": "C3",    "Region": "Rasht",                   "Color": "Light orange"},
            {"Cluster": "C4",    "Region": "Shiraz",                  "Color": "Green"},
            {"Cluster": "Noise", "Region": "—",                       "Color": "Light grey (6,648 rows)"},
        ])
        st.dataframe(alt_df, use_container_width=True, hide_index=True)

        st.markdown("##### Remaining Limitations")
        lim_df = pd.DataFrame([
            {"Limitation": "Daily DBSCAN noise", "Value": "55%",         "Action": "Documented honestly"},
            {"Limitation": "Sale memory",        "Value": "18 GB",       "Action": "Only sample executed"},
            {"Limitation": "Placeholder values", "Value": "111111, 500", "Action": "No market label applied"},
            {"Limitation": "Cluster imbalance",  "Value": "C0 ≈ 80%",    "Action": "Imbalance documented"},
        ])
        st.dataframe(lim_df, use_container_width=True, hide_index=True)

        note_box(
            "اجرای DBSCAN کامل روی daily با eps=25 و min_samples=386 به ۵ خوشه با ۵۵٪ نویز رسید، نه ۳ خوشه. "
            "این محدودیت ذات داده است، نه انتخاب پارامتر. بعضی مقادیر مثل ۱۱۱۱۱۱ و ۵۰۰ در پروفایل خوشه‌ها "
            "دیده می‌شوند. ما این‌ها را به‌عنوان بازار ارزان یا لاکچری برچسب نزدیم — صریحاً گفتیم مشکوک‌اند.",
            kind="warn",
        )

        st.markdown("##### Summary — Requirements vs Answers")
        sum_df = pd.DataFrame([
            {"Requirement": "Feature selection",         "Our Answer": "5 criteria · 4 features · correlation analysis"},
            {"Requirement": "K-Means k=10 on UTM+price", "Our Answer": "3 independent models · two-panel scatter"},
            {"Requirement": "Choose k via WCSS",         "Our Answer": "4 metrics · consensus at k=4 · also accept k=10"},
            {"Requirement": "DBSCAN with 3 clusters",    "Our Answer": "3 geographic clusters · 9-14% noise"},
        ])
        st.dataframe(sum_df, use_container_width=True, hide_index=True)

        note_box(
            "پروژه چهار خواستهٔ صورت تمرین را برآورده کرد. پشت هر تصمیم یک دلیل دامنه یا فنی است، "
            "و هر محدودیت صادقانه مستند شده. برای سیستم توصیه‌گر، لایهٔ اول را جغرافیایی پیشنهاد می‌کنیم "
            "— خوشه‌های DBSCAN — و لایهٔ دوم را بر اساس قیمت و اندازه در هر خوشه."
        )

    # ========================================================
    # TAB 8 — APPENDIX
    # ========================================================
    with tabs[7]:
        st.markdown('<div class="subtab-title">پیوست — مسیر مکمل</div>', unsafe_allow_html=True)
        st.caption("K-Means in extended feature space with PCA visualization")

        st.markdown("##### Supplementary K-Means vs Official")
        sup_cmp = pd.DataFrame([
            {"Group": "Sale",  "Rows": 545200, "Smallest Cluster": 3100, "Largest Cluster": 169473, "WCSS": 267433.7},
            {"Group": "Rent",  "Rows": 338688, "Smallest Cluster": 1823, "Largest Cluster": 88227,  "WCSS": 186129.7},
            {"Group": "Daily", "Rows": 17180,  "Smallest Cluster": 88,   "Largest Cluster": 4854,   "WCSS": 3368.4},
        ])
        st.dataframe(sup_cmp, use_container_width=True, hide_index=True)

        st.markdown("##### N10 — PCA Scatter: Sale")
        show_image("kmeans_pca_sales.png", "2D PCA projection of extended K-Means", width=1100)

        st.markdown("##### N11 — PCA Scatter: Rent")
        show_image("kmeans_pca_rent.png", "Note: C5 outlier cluster (expensive or noisy ads)", width=1100)

        st.markdown("##### N12 — PCA Scatter: Daily")
        show_image("kmeans_pca_daily.png", "Clusters appear as two parallel bands (cheap / expensive)", width=1100)

        st.markdown("##### N13 — WCSS Supplementary (k = 1..20)")
        show_image("wcss_supplementary.png", "Slope changes around k=5 · Vertical line at k=10", width=1100)

        st.markdown("##### Supplementary Cluster Profiles")
        sup_prof = pd.DataFrame([
            {"Group": "Sale",  "Largest Cluster": "C1 (apartment)", "Share": "31.1%", "Median Price": "2.2 B",   "Median Area": 76},
            {"Group": "Rent",  "Largest Cluster": "C2 (apartment)", "Share": "26.0%", "Median Price": "18.5 M",  "Median Area": 100},
            {"Group": "Daily", "Largest Cluster": "C1 (suite)",     "Share": "28.3%", "Median Price": "700,000", "Median Area": 90},
        ])
        st.dataframe(sup_prof, use_container_width=True, hide_index=True)


# ============================================================
# SECTION 3 — REGRESSION
# ============================================================
def regression_page():
    page_header(
        "💰 Regression",
        "Price prediction for sale and rental listings using LightGBM",
        key="back_regression",
    )

    tabs = st.tabs([
        "📌 Overview",
        "🏠 Sale Regression",
        "🔑 Rental Regression",
        "⚖️ Model Comparison",
        "📋 Summary",
    ])

    # ========================================================
    # TAB 1 — OVERVIEW
    # ========================================================
    with tabs[0]:
        st.markdown('<div class="subtab-title">مرور کلی بخش رگرسیون</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "538,090", "label": "Sale Records",    "sub": "after cleaning"},
            {"value": "353,121", "label": "Rental Records",  "sub": "after cleaning"},
            {"value": "78 / 29", "label": "Features (S/R)",  "sub": "engineered"},
            {"value": "LightGBM", "label": "Final Model",    "sub": "for both tasks"},
        ])

        st.markdown("##### Two Independent Regression Pipelines")
        overview_df = pd.DataFrame([
            {"Task": "Sale Regression",   "Records": "538,090", "Features": 78, "Model": "LightGBM", "Test R²": 0.7506, "MdAPE": "18.8%"},
            {"Task": "Rental Regression", "Records": "353,121", "Features": 29, "Model": "LightGBM (tuned)", "Test R²": 0.7162, "MAE": "6.6M"},
        ])
        st.dataframe(overview_df, use_container_width=True, hide_index=True)

        note_box(
            "دو خط لوله‌ی مستقل طراحی شد: یکی برای پیش‌بینی <b>قیمت فروش</b> و دیگری برای <b>اجاره‌ی ماهانه</b>. "
            "دلیل تفکیک: واحد اقتصادی متفاوت (میلیارد تومان در برابر میلیون ماهانه) و ماهیت متفاوت داده. "
            "هر دو مدل با LightGBM آموزش دیده‌اند."
        )

        note_box(
            "<b>نکته‌ی حیاتی برای ارائه:</b> هرگز R² فروش را با R² اجاره مستقیماً مقایسه نکنید. "
            "R² فروش روی متغیر تبدیل‌یافته‌ی log محاسبه شده (واریانس کمتر)، ولی R² اجاره مستقیماً روی مبالغ خام ریالی. "
            "این دو عدد در دو فضای متفاوت هستند.",
            kind="warn",
        )

    # ========================================================
    # TAB 2 — SALE REGRESSION
    # ========================================================
    with tabs[1]:
        st.markdown('<div class="subtab-title">رگرسیون فروش</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "538,090", "label": "Total Records", "sub": "after rent filter"},
            {"value": "430,472", "label": "Train (80%)",   "sub": "random_state=42"},
            {"value": "53,809",  "label": "Validation (10%)", "sub": "for early stopping"},
            {"value": "53,809",  "label": "Test (10%)",    "sub": "final evaluation"},
        ])

        # ---- Target formulation ----
        st.markdown("##### Target Formulation (Key Insight)")
        note_box(
            "مدل مستقیماً قیمت کل را پیش‌بینی نمی‌کند، بلکه <b>تفاضل لگاریتمی نسبت به مساحت مرجع</b> را می‌آموزد:<br><br>"
            "<code style='background:#fff; padding:4px 8px; border-radius:4px;'>"
            "target = ln(1 + adjusted_total_price) − ln(1 + price_size)"
            "</code><br><br>"
            "یعنی مدل در واقع <b>نرخ رشد قیمت به ازای لگاریتم مساحت</b> را یاد می‌گیرد. "
            "هنگام پیش‌بینی، مساحت بازگردانده شده و با تابع معکوس <code>expm1</code> قیمت کل محاسبه می‌شود."
        )

        # ---- Data split ----
        st.markdown("##### Data Split")
        split_df = pd.DataFrame([
            {"Split": "Train",      "Records": 430472, "Percent": "80%"},
            {"Split": "Validation", "Records": 53809,  "Percent": "10%"},
            {"Split": "Test",       "Records": 53809,  "Percent": "10%"},
        ])
        fig = px.bar(
            split_df, x="Split", y="Records",
            color="Split",
            color_discrete_map={"Train": "#1e3a8a", "Validation": "#f59e0b", "Test": "#dc2626"},
            text="Records",
        )
        fig.update_traces(texttemplate="%{text:,}", textposition="outside")
        fig.update_layout(
            yaxis_title="Number of Records",
            height=380,
            margin=dict(l=20, r=20, t=20, b=20),
            showlegend=False,
        )
        st.plotly_chart(fig, use_container_width=True)

        # ---- Outlier filtering ----
        st.markdown("##### Outlier Filtering")
        note_box(
            "با استفاده از روش دامنه میان‌چارکی (<b>1.5 × IQR</b>) بر روی لگاریتم قیمت بر متر مربع، "
            "به تفکیک هر دسته ملک (<code>cat3_slug</code>) داده‌های پرت شناسایی و حذف شدند."
        )

        # ---- Feature engineering ----
        st.markdown("##### Feature Engineering (78 features total)")
        fe_df = pd.DataFrame([
            {"Category": "Inflation Adjustment",  "Description": "Interpolated log coefficients to normalize price over time", "Count": "1"},
            {"Category": "Ratio Features",         "Description": "building_age, size_per_room, land_to_building_ratio, floor_ratio", "Count": "4"},
            {"Category": "Spatial Clustering",     "Description": "MiniBatchKMeans (100 clusters) + distance to city center", "Count": "2"},
            {"Category": "OOF Target Encoding",    "Description": "City, neighborhood, and clusters with 5-fold smoothing=20", "Count": "3+"},
            {"Category": "NLP (TF-IDF + SVD)",     "Description": "Text features from title/description (3000 → 30 components)", "Count": "30"},
            {"Category": "Keyword Flags",           "Description": "8 Persian keyword flags for special conditions", "Count": "8"},
            {"Category": "Raw & Categorical",      "Description": "Numerical features, ordinal categories, boolean flags", "Count": "~30"},
        ])
        st.dataframe(fe_df, use_container_width=True, hide_index=True)

        # ---- Missing values ----
        st.markdown("##### Missing Value Handling")
        note_box(
            "<b>Amenities (elevator, parking, warehouse, balcony):</b> filled with 0 (absence)<br>"
            "<b>Geo/Location:</b> nearest neighborhood via Haversine distance; missing coords from median; <code>has_geo</code> flag<br>"
            "<b>Land Area:</b> filled from building area + <code>has_land_area</code> flag<br>"
            "<b>Rare categories:</b> mapped to <code>unknown</code>; freq &lt; 50 merged into <code>other</code>"
        )

        # ---- Scaling + Polynomials ----
        st.markdown("##### Scaling & Polynomial Features")
        note_box(
            "<b>No StandardScaler / MinMaxScaler</b> used — tree-based models are scale-invariant because splits are order-based (<code>X_j ≤ c</code>).<br><br>"
            "<b>No PolynomialFeatures</b> class — instead, <b>domain-specific quadratic interactions</b> were built manually:<br>"
            "• <code>size × age</code> (interaction of area with building age)<br>"
            "• <code>size × rooms</code> (interaction of area with room count)"
        )

        # ---- Hyperparameters ----
        st.markdown("##### Hyperparameters (LightGBM)")
        hp_df = pd.DataFrame([
            {"Parameter": "n_estimators",  "Value": 3000, "Note": "with early stopping"},
            {"Parameter": "learning_rate", "Value": 0.03, "Note": "slow learning"},
            {"Parameter": "early_stopping", "Value": 50,  "Note": "rounds without improvement"},
        ])
        st.dataframe(hp_df, use_container_width=True, hide_index=True)

        # ---- Results ----
        st.markdown("##### Results")
        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown("###### Validation")
            val_df = pd.DataFrame([
                {"Metric": "R² (log)",    "Value": "0.7556"},
                {"Metric": "Log-RMSE",    "Value": "0.5472"},
                {"Metric": "MAE",         "Value": "~1.92 B"},
                {"Metric": "MdAPE",       "Value": "18.8%"},
            ])
            st.dataframe(val_df, use_container_width=True, hide_index=True)
        with col_b:
            st.markdown("###### Test")
            test_df = pd.DataFrame([
                {"Metric": "R² (log)",    "Value": "0.7506"},
                {"Metric": "Log-RMSE",    "Value": "0.5577"},
                {"Metric": "MAE",         "Value": "~2.06 B"},
                {"Metric": "MdAPE",       "Value": "18.8%"},
            ])
            st.dataframe(test_df, use_container_width=True, hide_index=True)

        note_box(
            "<b>MdAPE = 18.8%</b> یعنی نیمی از پیش‌بینی‌ها کمتر از ۱۸.۸٪ خطا دارند. "
            "این معیار از MAE قابل‌اعتمادتره چون دیتاست قیمت‌های پرت داره."
        )

        # ---- Feature Importance ----
        st.markdown("##### Feature Importance")
        show_image("Feature Importance for sale.jpg", "Top features for sale price prediction", width=1000)

        note_box(
            "اهمیت ویژگی‌ها با <code>feature_importances_</code> لایت‌جی‌بی‌ام بر اساس <b>تعداد دفعات انشعاب (Split Count)</b> "
            "استخراج شده. یعنی نشون می‌ده یه متغیر چند بار در طول ساخت درختان برای ایجاد مرز تصمیم استفاده شده."
        )

    # ========================================================
    # TAB 3 — RENTAL REGRESSION
    # ========================================================
    with tabs[2]:
        st.markdown('<div class="subtab-title">رگرسیون اجاره</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "353,121", "label": "Total Records", "sub": "all rental types"},
            {"value": "317,808", "label": "Train (90%)",   "sub": "large training set"},
            {"value": "17,656",  "label": "Validation (5%)","sub": "for tuning"},
            {"value": "17,657",  "label": "Test (5%)",     "sub": "final evaluation"},
        ])

        # ---- Target formulation ----
        st.markdown("##### Target Formulation — The Main Challenge")
        note_box(
            "چالش اصلی اجاره، ترکیب دو عدد «ودیعه/رهن» و «اجاره‌ی ماهانه» در یک عدد واحد است. "
            "دو فرمول متفاوت برای دو نوع اجاره استفاده شد."
        )

        st.markdown("###### For Regular Residential Rentals")
        note_box(
            "تبدیل رهن به اجاره‌ی ماهانه بر مبنای <b>۳٪ در ماه</b>:<br><br>"
            "<code style='background:#fff; padding:4px 8px; border-radius:4px;'>"
            "Equivalent Rent = Monthly Rent + (0.03 × Credit/Deposit)"
            "</code>"
        )

        st.markdown("###### For Temporary/Daily Rentals")
        note_box(
            "وزن‌دهی روزهای هفته و تعطیلات در طول سال، تقسیم بر ۱۲ ماه:<br><br>"
            "<code style='background:#fff; padding:4px 8px; border-radius:4px;'>"
            "Monthly Proxy = (241 × Regular + 105 × Weekend + 20 × Special) / 12"
            "</code>"
        )

        note_box(
            "سپس با استفاده از شاخص‌های تورمی، مبالغ به <b>سال پایه ۱۴۰۳</b> نرمال‌سازی شدند."
        )

        # ---- Outlier filtering ----
        st.markdown("##### Outlier Filtering")
        note_box(
            "حذف داده‌ها بر اساس Log-IQR و بازه‌ی کران‌دار ثابت بین "
            "<code>1,000,000</code> تا <code>1,000,000,000</code> واحد پولی."
        )

        # ---- Missing values ----
        st.markdown("##### Missing Value Handling")
        note_box(
            "<b>Luxury amenities (<code>has_luxury_amenities</code>):</b> "
            "ساختار سه‌وضعیتی — اگر همه NaN بود، مفقود می‌ماند؛ اگر بخشی معلوم بود و هیچ‌کدام موجود نبود، صفر می‌شد.<br><br>"
            "<b>Floor & rooms_count:</b> مقادیر ناقص با میانه (Median) جایگزین شدند.<br><br>"
            "<b>سایر مقادیر گمشده عددی:</b> به LightGBM سپرده شد چون ذاتاً NaN را در جهت بهینه هدایت می‌کند."
        )

        # ---- Feature engineering ----
        st.markdown("##### Feature Engineering (29 features total)")
        fe2_df = pd.DataFrame([
            {"Type": "Categorical", "Count": 9,  "Note": "OrdinalEncoder, unseen = -1"},
            {"Type": "Numeric",     "Count": 15, "Note": "Including ratio features"},
            {"Type": "Boolean",     "Count": 5,  "Note": "Amenity flags"},
        ])
        st.dataframe(fe2_df, use_container_width=True, hide_index=True)

        note_box(
            "نسبت‌های تعاملی شامل: مساحت به ازای اتاق، نسبت طبقه، تعداد واحد در طبقه و سن بنا.<br>"
            "تبدیل <code>log(1 + y)</code> برای متقارن‌سازی توزیع چوله‌ی اجاره."
        )

        # ---- Hyperparameter tuning ----
        st.markdown("##### Hyperparameter Tuning (RandomizedSearchCV)")
        note_box(
            "<b>Method:</b> RandomizedSearchCV<br>"
            "<b>Iterations:</b> 25<br>"
            "<b>Cross-Validation:</b> 5-Fold on log target<br>"
            "<b>Scoring:</b> neg_root_mean_squared_error"
        )

        search_space = pd.DataFrame([
            {"Parameter": "n_estimators",       "Range": "100 – 500"},
            {"Parameter": "learning_rate",      "Range": "0.01 – 0.15"},
            {"Parameter": "num_leaves",         "Range": "20 – 99"},
            {"Parameter": "max_depth",          "Range": "3 – 9"},
            {"Parameter": "min_child_samples",  "Range": "10 – 49"},
            {"Parameter": "subsample",          "Range": "0.6 – 1.0"},
            {"Parameter": "colsample_bytree",   "Range": "0.6 – 1.0"},
            {"Parameter": "reg_alpha (L1)",     "Range": "0 – 1"},
            {"Parameter": "reg_lambda (L2)",    "Range": "0 – 2"},
        ])
        st.dataframe(search_space, use_container_width=True, hide_index=True)

        note_box(
            "از ۱۲۵ برازش در طول CV، تعداد <b>۲۰ اجرا به دلیل محدودیت حافظه شکست خوردند</b> "
            "و نهایتاً بهترین مدل از میان اجراهای موفق انتخاب شد. این محدودیت صادقانه مستند شده.",
            kind="warn",
        )

        # ---- Results ----
        st.markdown("##### Results (on raw rental price scale)")
        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown("###### Validation")
            val2_df = pd.DataFrame([
                {"Metric": "R²",     "Value": "0.7048"},
                {"Metric": "MAE",    "Value": "~6,839,290"},
                {"Metric": "RMSE",   "Value": "~15,118,588"},
                {"Metric": "RMSLE",  "Value": "0.4586"},
            ])
            st.dataframe(val2_df, use_container_width=True, hide_index=True)
        with col_b:
            st.markdown("###### Test")
            test2_df = pd.DataFrame([
                {"Metric": "R²",     "Value": "0.7162"},
                {"Metric": "MAE",    "Value": "~6,620,953"},
                {"Metric": "RMSE",   "Value": "~14,545,131"},
                {"Metric": "RMSLE",  "Value": "0.4543"},
            ])
            st.dataframe(test2_df, use_container_width=True, hide_index=True)

        note_box(
            "معیارها روی <b>مقیاس اصلی قیمت اجاره‌ی ماهانه</b> (تومان/ریال) گزارش شدن، "
            "نه روی لگاریتم هدف. این یعنی اعداد مستقیماً قابل تفسیر هستن."
        )

        # ---- Feature Importance ----
        st.markdown("##### Feature Importance")
        show_image("Feature Importance for rent.jpg", "Top features for rental price prediction", width=1000)

    # ========================================================
    # TAB 4 — MODEL COMPARISON
    # ========================================================
    with tabs[3]:
        st.markdown('<div class="subtab-title">مقایسه مدل‌ها و دلایل انتخاب</div>', unsafe_allow_html=True)

        # ---- Why linear models fail ----
        st.markdown("##### Why Linear Models (Ridge / Lasso) Failed")
        note_box(
            "<b>۱. غیرخطی بودن شدید و وابستگی‌های پیچیده:</b><br>"
            "رابطه‌ی مساحت و محله با قیمت یکنواخت نیست — یک متر اضافه در منطقه ۱ تهران با یک متر در منطقه ۱۸ "
            "ارزش کاملاً متفاوتی دارد. مدل‌های خطی برای یادگیری این روابط نیازمند میلیاردها ضرب تعاملی دستی هستن، "
            "ولی درخت‌ها این تعاملات را ذاتاً کشف می‌کنند.<br><br>"
            "<b>۲. چولگی و حساسیت به داده‌های پرت:</b><br>"
            "مدل‌های خطی به شدت تحت تأثیر مقادیر کرانی قرار می‌گیرند."
        )

        # ---- Why LightGBM ----
        st.markdown("##### Why LightGBM Won over CatBoost / XGBoost")
        reasons_df = pd.DataFrame([
            {"Reason": "GOSS Sampling",         "Description": "Samples with large gradients — 3-5x faster training"},
            {"Reason": "EFB Bundling",          "Description": "Reduces feature dimensions by bundling exclusive features"},
            {"Reason": "Leaf-wise Growth",      "Description": "Better accuracy at same depth (vs depth-wise)"},
            {"Reason": "Native NaN Handling",   "Description": "No need for artificial imputation"},
            {"Reason": "Native Categorical",    "Description": "High-cardinality features (hundreds of neighborhoods)"},
        ])
        st.dataframe(reasons_df, use_container_width=True, hide_index=True)

        note_box(
            "<b>حجم داده:</b> بیش از ۵۰۰ هزار سطر → LightGBM با GOSS و EFB چندین برابر سریع‌تر از CatBoost و XGBoost.<br><br>"
            "<b>رشد درخت:</b> LightGBM درخت را از برگی که بیشترین کاهش در loss می‌دهد رشد می‌دهد "
            "(Leaf-wise)، در نتیجه با عمق یکسان دقت بالاتری می‌دهد.<br><br>"
            "<b>مدیریت NaN و Categorical:</b> نیازی به Imputation و One-Hot Encoding حجیم نبود."
        )

        # ---- Side-by-side comparison ----
        st.markdown("##### Side-by-Side Comparison")
        cmp_df = pd.DataFrame([
            {"Aspect": "Records",       "Sale": "538,090",  "Rent": "353,121"},
            {"Aspect": "Features",      "Sale": "78",        "Rent": "29"},
            {"Aspect": "Train Split",   "Sale": "80%",       "Rent": "90%"},
            {"Aspect": "Target",        "Sale": "Log-diff (area offset)", "Rent": "log1p(equivalent rent)"},
            {"Aspect": "R² (Test)",     "Sale": "0.7506",    "Rent": "0.7162"},
            {"Aspect": "Tuning",        "Sale": "Manual + Early Stop", "Rent": "RandomizedSearchCV (25 iter × 5-fold)"},
            {"Aspect": "Metric Space",  "Sale": "Log scale", "Rent": "Raw price scale"},
        ])
        st.dataframe(cmp_df, use_container_width=True, hide_index=True)

    # ========================================================
    # TAB 5 — SUMMARY
    # ========================================================
    with tabs[4]:
        st.markdown('<div class="subtab-title">جمع‌بندی</div>', unsafe_allow_html=True)

        stat_cards([
            {"value": "R² = 0.75", "label": "Sale Test R²",  "sub": "on log scale"},
            {"value": "R² = 0.72", "label": "Rent Test R²",  "sub": "on raw price"},
            {"value": "18.8%",      "label": "Sale MdAPE",   "sub": "median error"},
            {"value": "6.6M",       "label": "Rent MAE",      "sub": "Toman"},
        ])

        st.markdown("##### Key Achievements")
        note_box(
            "<b>۱. Sale Regression:</b> با ۷۸ ویژگی مهندسی‌شده و تکنیک‌های پیشرفته (OOF Target Encoding، "
            "Spatial Clustering، NLP روی متن) به R² = 0.75 روی داده‌ی تست رسیدیم.<br><br>"
            "<b>۲. Rental Regression:</b> با فرمول‌بندی دقیق تبدیل رهن-اجاره و RandomizedSearchCV، "
            "به R² = 0.72 روی مقیاس اصلی قیمت رسیدیم.<br><br>"
            "<b>۳. Feature Engineering:</b> در فروش ۷۸ ویژگی (شامل ۳۰ مؤلفه TF-IDF/SVD) و در اجاره ۲۹ ویژگی.<br><br>"
            "<b>۴. Tuning:</b> در فروش Early Stopping و در اجاره RandomizedSearchCV."
        )

        st.markdown("##### Critical Points for Defense")
        note_box(
            "<b>۱.</b> R² فروش (0.75) و R² اجاره (0.72) در دو فضای متفاوت محاسبه شدن "
            "(لگاریتمی در برابر خام). مستقیم قابل مقایسه نیستن.<br><br>"
            "<b>۲.</b> فرمول‌بندی log-diff در فروش (target = log(price) − log(area)) "
            "کلید موفقیت مدل بود — بدون این، پرت‌ها مدل رو خراب می‌کردن.<br><br>"
            "<b>۳.</b> OOF Target Encoding با ۵ فولد و smoothing=20 برای جلوگیری از Data Leakage حیاتی بود.<br><br>"
            "<b>۴.</b> LightGBM انتخاب شد چون روی داده‌ی نیم‌میلیونی سریع‌ترین و دقیق‌ترین بود.",
            kind="info",
        )

        note_box(
            "<b>محدودیت‌های صادقانه:</b><br>"
            "• در RandomizedSearchCV اجاره، ۲۰ اجرا از ۱۲۵ اجرا به‌خاطر حافظه شکست خوردند.<br>"
            "• دیتاست اجاره به‌شدت چوله بود و مجبور شدیم از log1p استفاده کنیم.<br>"
            "• مدل فروش فقط روی فروش‌های معمولی کار می‌کند؛ معاملات خاص (پیش‌فروش، مشارکت) استثنا شدن.",
            kind="warn",
        )


# ============================================================
# ABOUT
# ============================================================
def about_page():
    page_header("ℹ️ About", "Project information", key="back_about")
    st.markdown("""
    **Divar Real Estate Analytics**

    - **Course:** Quera AI Bootcamp — Summer 2026
    - **Project:** Real estate ads analysis and prediction
    - **Stack:** Python, Streamlit, Plotly, scikit-learn, pandas
    """)


# ============================================================
# ROUTER
# ============================================================
PAGES = {
    "home":                   home_page,
    "eda":                    eda_page,
    "descriptive_stats":      descriptive_stats_page,
    "hypothesis_tests":       hypothesis_tests_page,
    "bonus_hypothesis_tests": bonus_hypothesis_tests_page,
    "clustering":             clustering_page,
    "regression":             regression_page,
    "about":                  about_page,
}

PAGES[st.session_state.page]()